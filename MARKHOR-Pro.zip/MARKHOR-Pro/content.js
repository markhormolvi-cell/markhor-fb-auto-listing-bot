let isAutofilled = false;

// 🔄 AUTO-RECOVERY: If Facebook shows "Something went wrong" or crashes
if (document.body && (
    document.body.innerText.includes("Something went wrong") || 
    document.body.innerText.includes("Reload Page") || 
    document.body.innerText.includes("page isn't available") ||
    document.title.includes("Error")
)) {
    console.log("[MARKHOR] Facebook error page detected. Auto-reloading in 8 seconds...");
    setTimeout(() => {
        // Only reload if the error is still there
        if (document.body.innerText.includes("Something went wrong") || document.title.includes("Error")) {
            location.reload();
        }
    }, 8000);
}

// ─── Remote Block & Security Check ──────────────────────────────────────────
chrome.storage.local.get(["isBlocked", "systemMessage", "broadcast", "hasSynced", "lastToastTime"], (data) => {
  // 1. If not synced yet, show a loading screen (prevents bypass during refresh)
  if (!data.hasSynced) {
    showSyncOverlay();
    return;
  }

  // 2. If blocked, show the full-screen block overlay
  if (data.isBlocked) {
    showBlockedOverlay(data.systemMessage);
    return;
  }

  // 3. If not blocked, check for broadcasts
  if (data.broadcast && data.broadcast.trim() !== "") {
    const now = Date.now();
    const lastToast = data.lastToastTime || 0;
    if (now - lastToast > 24 * 60 * 60 * 1000) {
      showSystemNotification(data.broadcast);
      chrome.storage.local.set({ lastToastTime: now });
    }
  }
});

// LIVE MESSAGE LISTENER: Sync status and Block updates
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;

  // If sync completes, check if we need to remove the sync overlay
  if (changes.hasSynced && changes.hasSynced.newValue === true) {
    const syncOverlay = document.getElementById('markhor-sync-overlay');
    if (syncOverlay) syncOverlay.remove();

    // After sync, if blocked, show blocked overlay
    chrome.storage.local.get(["isBlocked", "systemMessage"], (d) => {
      if (d.isBlocked) showBlockedOverlay(d.systemMessage);
    });
  }

  // If block status changes live
  if (changes.isBlocked) {
    if (changes.isBlocked.newValue === true) {
      chrome.storage.local.get("systemMessage", (d) => {
        showBlockedOverlay(d.systemMessage);
      });
    } else {
      const blockedOverlay = document.getElementById('markhor-blocked-overlay');
      if (blockedOverlay) blockedOverlay.remove();
      location.reload(); // Refresh to start script execution
    }
  }
  if (changes.broadcast && changes.broadcast.newValue && changes.broadcast.newValue.trim() !== "") {
    showSystemNotification(changes.broadcast.newValue);
    chrome.storage.local.set({ lastToastTime: Date.now() });
  }
});

// 🚀 BACKGROUND-SAFE UPGRADES (Solution for 40+ Tabs)
try {
  // 1. Visibility Spoof: Tricking React into thinking tab is always active
  Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
  Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });
} catch (e) { console.warn("[MARKHOR] Visibility spoof failed:", e); }

// 2. Background Timer: Bypasses background tab throttling using the Service Worker
async function workerSleep(ms) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ action: "bgSleep", ms: ms }, () => {
      resolve();
    });
  });
}

// GLOBAL BLOCK CHECK: All incoming messages will be ignored if blocked or not yet synced
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "FORCE_STOP") { location.reload(); return; }
  if (request.action === "show_toast") { showSystemNotification(request.message); return; }
  chrome.storage.local.get(["isBlocked", "hasSynced"], (data) => {
    if (!data.hasSynced || data.isBlocked === true) {
      console.log("MARKHOR: Action ignored - Waiting for server or User is blocked.");
      return;
    }
  });
});

function showLicenseModal() {
  if (document.getElementById('markhor-license-modal')) return;

  const modal = document.createElement("div");
  modal.id = 'markhor-license-modal';
  modal.style.cssText = `
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.95);
    z-index: 999999999;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    font-family: 'Outfit', sans-serif;
    color: white;
    text-align: center;
  `;

  modal.innerHTML = `
    <div style="background: #111; padding: 50px; border: 1px solid #ff3131; border-radius: 30px; width: 400px; box-shadow: 0 0 50px rgba(255,49,49,0.2);">
      <h1 style="color: #ff3131; font-weight: 900; margin-bottom: 10px;">LICENSE REQUIRED</h1>
      <p style="color: #888; font-size: 14px; margin-bottom: 30px;">This extension is now in Pro Mode. Please enter your license key to continue.</p>
      
      <input type="text" id="licenseKeyInput" placeholder="MARKHOR-XXXX-XXXX" style="width: 100%; padding: 15px; background: #000; border: 1px solid #333; border-radius: 12px; color: white; text-align: center; font-family: monospace; margin-bottom: 20px;">
      
      <button id="activateBtn" style="width: 100%; padding: 15px; background: #ff3131; border: none; border-radius: 12px; color: white; font-weight: bold; cursor: pointer; transition: 0.3s;">ACTIVATE NOW</button>
      
      <p style="margin-top: 20px; font-size: 11px; color: #555;">Locked to Device ID: <span id="currentDeviceId">-</span></p>
    </div>
  `;

  document.documentElement.appendChild(modal);

  chrome.storage.local.get("deviceId", (d) => {
    document.getElementById('currentDeviceId').textContent = d.deviceId || "Generating...";
  });

  document.getElementById('activateBtn').onclick = () => {
    const key = document.getElementById('licenseKeyInput').value.trim();
    if (key.length < 5) {
      alert("Invalid Key Format!");
      return;
    }
    // Tell background to validate
    chrome.runtime.sendMessage({ action: "validateLicense", key: key }, (response) => {
      if (response && response.success) {
        modal.remove();
        location.reload();
      } else {
        alert(response.message || "Invalid or Already Used License Key!");
      }
    });
  };
}

function showSystemNotification(msg) {
  if (document.getElementById('markhor-toast')) document.getElementById('markhor-toast').remove();

  const toast = document.createElement("div");
  toast.id = 'markhor-toast';
  toast.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: #ff3131;
    color: white;
    padding: 20px;
    border-radius: 15px;
    z-index: 999999;
    font-family: 'Outfit', sans-serif;
    box-shadow: 0 10px 30px rgba(0,0,0,0.5);
    max-width: 300px;
    animation: slideIn 0.5s ease-out;
  `;
  toast.innerHTML = `
    <div style="font-weight: 900; margin-bottom: 5px;">MARKHOR UPDATE</div>
    <div style="font-size: 14px; margin-bottom: 10px;">${msg}</div>
    <button id="toastDismissBtn" style="background: white; color: #ff3131; border: none; padding: 5px 15px; border-radius: 8px; cursor: pointer; font-weight: 900; font-size: 12px;">Dismiss</button>
  `;
  document.documentElement.appendChild(toast);

  const dismissBtn = toast.querySelector("#toastDismissBtn");
  if (dismissBtn) {
    dismissBtn.addEventListener("click", () => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      setTimeout(() => toast.remove(), 500);
    });
  }

  // Auto-hide after 15 seconds
  setTimeout(() => {
    if (toast.parentNode) {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      setTimeout(() => toast.remove(), 500);
    }
  }, 15000);
}

const style = document.createElement('style');
style.textContent = `@keyframes slideIn { from { transform: translateX(100%); } to { transform: translateX(0); } }`;
document.head.appendChild(style);

function showSyncOverlay() {
  if (document.getElementById('markhor-sync-overlay')) return;
  const overlay = document.createElement("div");
  overlay.id = 'markhor-sync-overlay';
  overlay.style.cssText = `
    position: fixed; inset: 0; background: #000; color: #ff3131;
    z-index: 999999999; display: flex; flex-direction: column;
    justify-content: center; align-items: center; font-family: 'Outfit', sans-serif;
  `;
  overlay.innerHTML = `
    <h1 style="font-size: 32px; font-weight: 900; letter-spacing: 3px;">MARKHOR</h1>
    <p style="color: #666; margin-top: 10px;">Establishing secure connection...</p>
    <div style="margin-top: 30px; width: 40px; height: 40px; border: 3px solid #333; border-top-color: #ff3131; border-radius: 50%; animation: spin 1s linear infinite;"></div>
  `;
  const style = document.createElement('style');
  style.textContent = `@keyframes spin { to { transform: rotate(360deg); } }`;
  document.head.appendChild(style);
  document.documentElement.appendChild(overlay);
}

function showBlockedOverlay(message) {
  if (document.getElementById('markhor-blocked-overlay')) return;

  // Remove sync overlay if exists
  const syncOverlay = document.getElementById('markhor-sync-overlay');
  if (syncOverlay) syncOverlay.remove();

  const overlay = document.createElement("div");
  overlay.id = 'markhor-blocked-overlay';
  overlay.style.cssText = `
    position: fixed; inset: 0; background: #000; color: #ff3131;
    z-index: 999999999; display: flex; flex-direction: column;
    justify-content: center; align-items: center; font-family: 'Outfit', sans-serif;
    text-align: center; padding: 20px;
  `;
  overlay.innerHTML = `
    <h1 style="font-size: 48px; font-weight: 900; letter-spacing: 5px; margin-bottom: 20px;">MARKHOR SECURE</h1>
    <p style="font-size: 20px; color: #fff; max-width: 600px;">${message || "Your access has been restricted by the administrator."}</p>
    <div style="margin-top: 40px; padding: 15px 30px; border: 1px solid #ff3131; border-radius: 12px; font-weight: bold;">
      ACTION REQUIRED: CONTACT ADMIN
    </div>
  `;
  document.documentElement.appendChild(overlay);
  // Stop further execution
  throw new Error("MARKHOR: Execution blocked by remote administrator.");
}

// ─── Helper: Parse a specific param from window.location.hash ────────────────
function getHashParam(paramName) {
  const hash = window.location.hash.replace("#", "");
  const params = new URLSearchParams(hash);
  return params.get(paramName);
}

// ─── Type Location: Set value instantly in background tab ────────────────────
async function typeLocationIntoField(locationName) {
  console.log(`[typeLocation] Setting location: "${locationName}"`);

  const locationSelectors = [
    'input[aria-label="Location"]',
    'input[aria-label="location"]',
    'input[placeholder="Location"]',
    'input[placeholder="Enter a location"]',
    'input[placeholder="Add a location"]',
    'input[aria-label*="ocation"]',
    'div[aria-label="Location"] input',
  ];

  let locationInput = null;
  for (const selector of locationSelectors) {
    locationInput = document.querySelector(selector);
    if (locationInput) break;
  }

  if (!locationInput) {
    console.warn("[typeLocation] Could not find input.");
    return false;
  }

  // 🚀 Step 1: Scroll & Focus
  locationInput.scrollIntoView({ behavior: "smooth", block: "center" });
  await sleep(400);
  locationInput.focus();
  locationInput.click();

  // 🚀 Step 2: React-Safe Value Setting
  const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
  nativeSetter.call(locationInput, ""); // Clear
  locationInput.dispatchEvent(new Event("input", { bubbles: true }));

  nativeSetter.call(locationInput, locationName); // Set real value
  locationInput.dispatchEvent(new Event("input", { bubbles: true }));
  locationInput.dispatchEvent(new Event("change", { bubbles: true }));

  // 🚀 Step 3: The "Magic Trigger" for Suggestions (Space + Backspace)
  await sleep(150);
  nativeSetter.call(locationInput, locationName + " ");
  locationInput.dispatchEvent(new Event("input", { bubbles: true }));
  locationInput.dispatchEvent(new KeyboardEvent('keydown', { key: ' ', bubbles: true }));
  
  await sleep(150);
  nativeSetter.call(locationInput, locationName);
  locationInput.dispatchEvent(new Event("input", { bubbles: true }));
  locationInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Backspace', bubbles: true }));

  console.log("[typeLocation] ✅ Suggestions triggered successfully.");
  return true;
}

// ─── Helper: get React fiber from a DOM element ───────────────────────────────
function getReactFiber(el) {
  const key = Object.keys(el).find(
    (k) =>
      k.startsWith("__reactFiber") ||
      k.startsWith("__reactInternalInstance") ||
      k.startsWith("__reactFiber$") ||
      k.startsWith("__reactProps")
  );
  return key ? el[key] : null;
}

// ─── Helper: walk fiber tree upward AND downward for any event handler ─────────
function fireReactEventOnFiber(el, eventName = "onClick") {
  const fiber = getReactFiber(el);
  if (!fiber) return false;

  let node = fiber;
  let attempts = 0;
  while (node && attempts < 40) {
    attempts++;
    const props = node.memoizedProps || node.pendingProps || {};
    if (typeof props[eventName] === "function") {
      console.log(`[fireReactEventOnFiber] Found ${eventName} on fiber node (upward walk).`);
      try {
        props[eventName]({
          type: "click", target: el, currentTarget: el, bubbles: true, cancelable: true,
          preventDefault: () => { }, stopPropagation: () => { },
        });
        return true;
      } catch (e) {
        console.warn("[fireReactEventOnFiber] Error calling handler:", e);
      }
    }
    node = node.return;
  }

  function walkDown(fiberNode, depth = 0) {
    if (!fiberNode || depth > 15) return false;
    const props = fiberNode.memoizedProps || fiberNode.pendingProps || {};
    if (typeof props[eventName] === "function") {
      console.log(`[fireReactEventOnFiber] Found ${eventName} on fiber child node.`);
      try {
        props[eventName]({
          type: "click", target: el, currentTarget: el, bubbles: true, cancelable: true,
          preventDefault: () => { }, stopPropagation: () => { },
        });
        return true;
      } catch (e) { }
    }
    return walkDown(fiberNode.child, depth + 1) || walkDown(fiberNode.sibling, depth + 1);
  }

  return walkDown(fiber);
}

// ─── Helper: full realistic mouse event sequence with real coordinates ─────────
async function simulateMouseSequence(el) {
  el.scrollIntoView({ behavior: "instant", block: "center" });
  await new Promise((r) => setTimeout(r, 100));

  const rect = el.getBoundingClientRect();
  if (!rect || rect.width === 0) return;

  const x = rect.left + rect.width / 2;
  const y = rect.top + rect.height / 2;

  const shared = {
    bubbles: true, cancelable: true, view: window,
    clientX: x, clientY: y, screenX: window.screenX + x, screenY: window.screenY + y,
    movementX: 0, movementY: 0, button: 0, buttons: 1,
  };

  const events = [
    new PointerEvent("pointerover", { ...shared, pointerId: 1, isPrimary: true }),
    new MouseEvent("mouseover", shared),
    new PointerEvent("pointerenter", { ...shared, pointerId: 1, isPrimary: true }),
    new MouseEvent("mouseenter", shared),
    new PointerEvent("pointermove", { ...shared, pointerId: 1, isPrimary: true }),
    new MouseEvent("mousemove", shared),
    new PointerEvent("pointerdown", { ...shared, pointerId: 1, isPrimary: true }),
    new MouseEvent("mousedown", shared),
    new PointerEvent("pointerup", { ...shared, pointerId: 1, isPrimary: true }),
    new MouseEvent("mouseup", shared),
    new MouseEvent("click", shared),
  ];

  for (const event of events) {
    el.dispatchEvent(event);
    await new Promise((r) => setTimeout(r, 20));
  }
}

// ─── Helper: elementFromPoint click ──────────────────────────────────────────
async function clickViaPoint(el) {
  el.scrollIntoView({ behavior: "instant", block: "center" });
  await new Promise((r) => setTimeout(r, 100));

  const rect = el.getBoundingClientRect();
  const x = Math.round(rect.left + rect.width / 2);
  const y = Math.round(rect.top + rect.height / 2);

  const topEl = document.elementFromPoint(x, y);
  if (!topEl) return false;

  console.log(`[clickViaPoint] elementFromPoint hit:`, topEl.tagName, topEl.className?.slice?.(0, 60));
  await simulateMouseSequence(topEl);
  return true;
}

// ─── Helper: fire ALL click methods on an element simultaneously ──────────────
async function bruteForceClick(el) {
  console.log("[bruteForceClick] Firing all click strategies on:", el.tagName, el.innerText?.trim()?.slice(0, 50));

  try { el.click(); } catch (e) { }
  await new Promise((r) => setTimeout(r, 50));

  fireReactEventOnFiber(el, "onClick");
  await new Promise((r) => setTimeout(r, 50));

  fireReactEventOnFiber(el, "onMouseDown");
  fireReactEventOnFiber(el, "onMouseUp");
  await new Promise((r) => setTimeout(r, 50));

  await simulateMouseSequence(el);
  await new Promise((r) => setTimeout(r, 50));

  await clickViaPoint(el);
  await new Promise((r) => setTimeout(r, 50));

  let parent = el.parentElement;
  let levels = 0;
  while (parent && levels < 5) {
    try { fireReactEventOnFiber(parent, "onClick"); } catch (e) { }
    try { parent.click(); } catch (e) { }
    parent = parent.parentElement;
    levels++;
    await new Promise((r) => setTimeout(r, 30));
  }
}

// ─── Helper: check if Facebook accepted the location ─────────────────────────
function isLocationAccepted() {
  const allText = document.body.innerText || "";
  const hasError = allText.toLowerCase().includes("please enter a valid location");
  const locationInput = document.querySelector(
    'input[aria-label="Location"], input[aria-label="location"], input[placeholder="Location"]'
  );
  const inputHasValue = locationInput && locationInput.value?.trim().length > 2;
  return !hasError && inputHasValue;
}

// ─── Helper: find suggestion elements near the location input ─────────────────
function findSuggestionElements(locationInput, typedText) {
  const candidates = [];
  const searchTerms = typedText.toLowerCase().split(/[\s,]+/).filter((w) => w.length > 2);

  let container = locationInput.parentElement;
  for (let i = 0; i < 8; i++) {
    if (!container) break;
    container = container.parentElement;
  }

  if (container) {
    const allEls = container.querySelectorAll(
      "div, li, span, a, [role='option'], [role='listitem'], [role='menuitem'], [tabindex]"
    );
    allEls.forEach((el) => {
      const text = (el.innerText || el.textContent || "").trim().toLowerCase();
      if (text.length < 3 || text.length > 300) return;
      if (el === locationInput) return;
      const matchesSearch = searchTerms.some((term) => text.includes(term));
      if (!matchesSearch) return;
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;
      if (rect.top < 0 || rect.bottom > window.innerHeight) return;
      const inputRect = locationInput.getBoundingClientRect();
      if (rect.top < inputRect.bottom - 10) return;
      candidates.push({ el, rect, text });
    });
  }

  if (candidates.length === 0) {
    const inputRect = locationInput.getBoundingClientRect();
    const allEls = document.querySelectorAll("div, li, span, [role='option'], [role='listitem'], [tabindex]");
    allEls.forEach((el) => {
      const text = (el.innerText || el.textContent || "").trim().toLowerCase();
      if (text.length < 3 || text.length > 300) return;
      if (el === locationInput) return;
      const matchesSearch = searchTerms.some((term) => text.includes(term));
      if (!matchesSearch) return;
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;
      if (rect.top < inputRect.bottom - 10) return;
      candidates.push({ el, rect, text });
    });
  }

  const inputRect = locationInput.getBoundingClientRect();
  candidates.sort((a, b) => Math.abs(a.rect.top - inputRect.bottom) - Math.abs(b.rect.top - inputRect.bottom));

  const deduped = [];
  for (const c of candidates) {
    const isChild = deduped.some((d) => d.el.contains(c.el));
    const isParent = deduped.some((d) => c.el.contains(d.el));
    if (!isChild && !isParent) deduped.push(c);
  }

  console.log(`[findSuggestionElements] Found ${deduped.length} candidate(s):`,
    deduped.slice(0, 3).map((c) => c.text.slice(0, 60)));
  return deduped;
}

// ─── Helper: re-trigger Facebook's autocomplete ───────────────────────────────
async function reTriggerAutocomplete(input) {
  input.focus();
  await new Promise((r) => setTimeout(r, 200));
  const lastChar = (input.value || "").slice(-1) || "a";
  ["keydown", "keypress", "input", "change", "keyup"].forEach((type) => {
    const event = type === "input" || type === "change"
      ? new Event(type, { bubbles: true })
      : new KeyboardEvent(type, { key: lastChar, bubbles: true });
    input.dispatchEvent(event);
  });
  await new Promise((r) => setTimeout(r, 800));
}

// ─── MAIN: selectLocationFromDropdown (RELIABILITY FIRST) ─────────────────
async function selectLocationFromDropdown() {
  console.log("[selectLocationFromDropdown] Waiting 2.5s for suggestions to load...");
  
  // 🚀 User Requested Wait
  await sleep(2500);

  const maxRetries = 40; 
  let attempts = 0;

  while (attempts < maxRetries) {
    attempts++;

    // 1. Ultra-Specific Selectors for FB Marketplace Edit/Create
    const selectors = [
      'div[role="listbox"] div[role="option"]',
      'div[role="gridcell"]',
      'div[aria-label="Location suggestions"] [role="button"]',
      'ul[role="listbox"] li[role="option"]',
      'div[role="option"]',
      'div.x1i10hfl[role="button"]',
      'div.x193iq5w[role="button"]'
    ];

    for (const selector of selectors) {
      const options = document.querySelectorAll(selector);
      if (options.length > 0) {
        // We pick the VERY FIRST suggestion found
        const op = options[0]; 
        const text = (op.innerText || op.textContent || "").trim();
        
        if (text.length > 0) {
          console.log(`✅ [MARKHOR] Selecting FIRST suggestion: "${text}"`);
          
          // COORDINATE-BASED NUCLEAR CLICK
          const rect = op.getBoundingClientRect();
          const evOpts = { bubbles: true, cancelable: true, view: window, clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2 };
          
          // Hover first (triggers React listeners)
          op.dispatchEvent(new MouseEvent("mouseover", evOpts));
          await sleep(50);
          
          // Sequence of events
          op.dispatchEvent(new PointerEvent("pointerdown", { ...evOpts, isPrimary: true }));
          op.dispatchEvent(new MouseEvent("mousedown", evOpts));
          op.dispatchEvent(new PointerEvent("pointerup", { ...evOpts, isPrimary: true }));
          op.dispatchEvent(new MouseEvent("mouseup", evOpts));
          op.dispatchEvent(new MouseEvent("click", evOpts));
          
          op.click(); // Native fallback

          // Wait to see if it worked
          await sleep(1000);
          
          // Verify if the suggestion list is gone (meaning success)
          const stillThere = document.querySelector(selector);
          if (!stillThere) {
             console.log("🚀 Selection Confirmed!");
             return true;
          }
        }
      }
    }

    // 2. Keyboard Fallback (ArrowDown + Enter) as a backup
    if (attempts % 5 === 0) {
      const input = document.querySelector('input[aria-label="Location"], input[aria-label="location"], input[placeholder="Location"]');
      if (input) {
        console.log("[selectLocationFromDropdown] Triggering Keyboard Backup...");
        input.focus();
        input.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true, keyCode: 40 }));
        await sleep(200);
        input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true, keyCode: 13 }));
      }
    }

    await sleep(800); // Wait before next retry
  }
  
  console.error("[selectLocationFromDropdown] FAILED after maximum retries.");
  return false;
}

async function autofillData() {
  if (isAutofilled) return;

  // 🚀 SAFEGUARD: Do not auto-start filling if we are on the EDIT/DRAFT page.
  if (window.location.href.includes("/marketplace/edit/") && !window.location.hash.includes("fill-missing=1")) {
    console.log("MARKHOR: Draft page detected. Skipping automatic autofill to protect existing data.");
    return;
  }

  const isFillMissingMode = window.location.hash.includes("fill-missing=1");
  console.log(`[autofillData] Starting — Mode: ${isFillMissingMode ? "Fill Missing Fields Only" : "Full Autofill"}`);

  isAutofilled = true;

  // CRITICAL: Wait for Facebook's React UI to load existing data
  console.log("MARKHOR: Waiting for page to load existing data...");
  await sleep(isFillMissingMode ? 4000 : 1500);

  // ─── Context Check ────────────────────────────────────────────────────────
  if (!chrome.runtime?.id) {
    console.warn("MARKHOR: Extension context invalidated. Please refresh the page.");
    return;
  }

  const hash = window.location.hash;
  const isBatchB = hash.includes("batch=B");
  const suffix = isBatchB ? "_B" : "";

  try {
    const keys = [
      "title", "price", "description", "category", "condition", "availability", "productTag", "images", "locationsList"
    ].map(k => k + suffix);

    chrome.storage.local.get(keys, async (raw_data) => {
      // Normalize data (remove suffixes for internal use)
      const data = {};
      Object.keys(raw_data).forEach(k => {
        const baseKey = k.replace("_B", "");
        data[baseKey] = raw_data[k];
      });

      console.log(`MARKHOR: Starting RELIABILITY-FIRST Sequential Autofill (Batch: ${isBatchB ? 'B' : 'A'})...`);

      // 1. IMAGE UPLOAD FIRST (PRIORITY)
      if (data.images && data.images.length > 0) {
        const existingImages = document.querySelectorAll('div[aria-label*="Remove photo"], div[aria-label*="photo"], img[src*="scontent"]');
        if (isFillMissingMode && existingImages.length > 0) {
          console.log("MARKHOR: Images already exist, skipping upload.");
        } else {
          let imgIndex = 0;
          if (hash && hash.includes("idx=")) imgIndex = parseInt(hash.split("idx=")[1]) || 0;
          imgIndex = imgIndex % data.images.length;

          console.log("MARKHOR: Uploading Image index:", imgIndex);
          for (let i = 0; i < 30; i++) {
            const success = await uploadSingleImage(data.images[imgIndex]);
            if (success) break;
            await sleep(500);
          }

          console.log("MARKHOR: Waiting 5 seconds for image processing...");
          await sleep(5000);
        }
      }

      // 2. DATA ENTRY (One by one for maximum stability)
      console.log("MARKHOR: Filling Title...");
      await retryFill(["Title", "What are you selling?", "Product Title"], data.title, false, 30);
      await sleep(500);

      console.log("MARKHOR: Filling Price...");
      await retryFill(["Price", "Price (PKR)", "Amount"], data.price, false, 30);
      await sleep(500);

      console.log("MARKHOR: Setting Category...");
      for (let i = 0; i < 50; i++) {
        if (await selectDropdown("Category", data.category)) break;
        await sleep(800);
      }

      console.log("MARKHOR: Setting Condition...");
      for (let i = 0; i < 50; i++) {
        if (await selectDropdown("Condition", data.condition)) break;
        await sleep(800);
      }

      console.log("MARKHOR: Filling Description...");
      await retryFill(["Description", "Write a description"], data.description, true, 30);
      await sleep(500);

      console.log("MARKHOR: Setting Availability...");
      await selectDropdown("Availability", data.availability || "List as in stock");

      if (data.productTag) {
        console.log("MARKHOR: Filling Tags...");
        await sleep(1000);
        fillProductTag(data.productTag);
      }

      // Location Support
      if (data.locationsList) {
        const locationsArray = data.locationsList.split("\n").map(l => l.trim()).filter(l => l.length > 0);
        if (locationsArray.length > 0) {
          let locIndex = 0;
          if (hash && hash.includes("idx=")) locIndex = parseInt(hash.split("idx=")[1]) || 0;
          locIndex = locIndex % locationsArray.length;
          const targetLoc = locationsArray[locIndex];

          console.log("MARKHOR: Filling Location:", targetLoc);
          const typed = await typeLocationIntoField(targetLoc);
          if (typed) {
            await sleep(1500);
            await selectLocationFromDropdown();
          }
        }
      }

      console.log("MARKHOR: Stability Autofill Complete! (100% Success)");
    });
  } catch (e) {
    console.warn("MARKHOR: Error during storage access.");
  }
}

async function retryFill(placeholders, value, isTextArea = false, maxRetries = 25) {
  if (!value) return true;
  for (let i = 0; i < maxRetries; i++) {
    if (await fillFieldByPlaceholder(placeholders, value, isTextArea)) return true;
    await sleep(200); // Optimized for speed: check every 200ms instead of 1000ms
  }
  return false;
}

function sleep(ms) {
  return workerSleep(ms);
}

/* DIAGNOSTIC: LOG ALL POTENTIAL FIELDS */
function logAllFields() {
  console.log("MARKHOR DIAGNOSTIC: Scanning all inputs...");
  const inputs = document.querySelectorAll("input, textarea, div[role='textbox']");
  inputs.forEach((el, i) => {
    console.log(`MARKHOR DIALOG [${i}]:`, {
      tag: el.tagName,
      type: el.getAttribute("type"),
      placeholder: el.getAttribute("placeholder"),
      ariaLabel: el.getAttribute("aria-label")
    });
  });
}

/* HELPER: FIND BY PLACEHOLDER OR ARIA-LABEL AND TYPE */
async function fillFieldByPlaceholder(placeholders, value, isTextArea = false) {
  const fillMissingOnly = window.location.hash.includes("fill-missing=1");
  if (!value) return true;
  if (typeof placeholders === "string") placeholders = [placeholders];

  let target = null;

  // Search through all provided placeholder variations
  for (const placeholder of placeholders) {
    // Standard input / textarea
    target =
      document.querySelector(`input[placeholder="${placeholder}"]`) ||
      document.querySelector(`textarea[placeholder="${placeholder}"]`);

    // Contenteditable div with aria-label or placeholder attribute
    if (!target) {
      target =
        document.querySelector(`div[aria-label="${placeholder}"][contenteditable="true"]`) ||
        document.querySelector(`div[data-placeholder="${placeholder}"][contenteditable="true"]`) ||
        document.querySelector(`div[role="textbox"][aria-label="${placeholder}"]`);
    }

    if (target) break;
  }

  // Fallback search logic
  if (!target) {
    const elements = document.querySelectorAll("span, label, div.x1lliihq");
    for (const el of elements) {
      const text = el.innerText ? el.innerText.trim().toLowerCase() : "";
      for (const p of placeholders) {
        if (text === p.toLowerCase()) {
          let container = el.closest('div[role="none"]') || el.parentElement;
          target = container.querySelector("input, textarea, div[role='textbox']");
          if (target) break;
          let next = el.nextElementSibling;
          if (next) target = next.querySelector("input, textarea, div[role='textbox']") || (next.matches("input, textarea, div[role='textbox']") ? next : null);
        }
        if (target) break;
      }
      if (target) break;
    }
  }

  if (!target) {
    return false;
  }

  // ─── Fill-Missing Guard ───────────────────────────────────────────────────
  if (fillMissingOnly) {
    const isContentEditable = target.isContentEditable || target.getAttribute("contenteditable") === "true";
    const existingValue = isContentEditable ? (target.innerText || "").trim() : (target.value || "").trim();

    if (existingValue.length > 0 && existingValue !== "0" && existingValue !== "$0" && existingValue !== "PKR 0" && existingValue !== "0.00") {
      console.log(`[MARKHOR] SKIPPED (fill-missing=1): "${existingValue}" — Field: ${placeholders[0]}`);
      return true; // Skip — field already has data
    }
  }

  // ─── Focus & Insert Value ─────────────────────────────────────────────────
  target.scrollIntoView({ behavior: "smooth", block: "center" });
  await new Promise((r) => setTimeout(r, 100)); // Sleep slightly

  target.focus();
  await new Promise((r) => setTimeout(r, 100));

  const isContentEditable = target.isContentEditable || target.getAttribute("contenteditable") === "true";

  try {
    if (isContentEditable) {
      document.execCommand("selectAll", false, null);
      document.execCommand("insertText", false, value);
    } else {
      document.execCommand("selectAll", false, null);
      document.execCommand("insertText", false, value);
    }

    const events = ["input", "change", "blur", "keyup"];
    events.forEach((eventType) => {
      target.dispatchEvent(new Event(eventType, { bubbles: true }));
    });
    return true;
  } catch (e) {
    return false;
  }
}

/* UPLOAD ONLY ONE IMAGE (POWERFUL VERSION) */
async function uploadSingleImage(imageUrl) {
  console.log("MARKHOR: Attempting to find image input...");

  // Facebook Marketplace specific image inputs
  const selectors = [
    "input[type='file'][accept*='image']",
    "input[type='file'][multiple]",
    "input[type='file']"
  ];

  let uploadInput = null;
  for (const selector of selectors) {
    const inputs = document.querySelectorAll(selector);
    for (const input of inputs) {
      // Marketplace images usually have 'multiple' or specific aria-labels
      if (input.accept.includes("image") || input.hasAttribute("multiple")) {
        uploadInput = input;
        break;
      }
    }
    if (uploadInput) break;
  }

  if (uploadInput && imageUrl) {
    try {
      const res = await fetch(imageUrl);
      const blob = await res.blob();
      let file = new File([blob], "product_image.jpg", { type: "image/jpeg" });
      let dt = new DataTransfer();
      dt.items.add(file);
      uploadInput.files = dt.files;

      // Dispatch multiple events to ensure React picks it up
      uploadInput.dispatchEvent(new Event("change", { bubbles: true }));
      uploadInput.dispatchEvent(new Event("input", { bubbles: true }));

      console.log("MARKHOR: ✅ Image uploaded successfully to focused tab.");
      return true;
    } catch (e) {
      console.error("MARKHOR: ❌ Image upload error:", e);
      return false;
    }
  }
  return false;
}

/* DROPDOWN IMPROVED */
async function selectDropdown(label, value) {
  if (!value) return true;
  const fillMissingOnly = window.location.hash.includes("fill-missing=1");
  const emptyPlaceholders = ["", "select", "choose", "none", "please select", "select an option", "pick one", "-", "--", "category", "condition", "select a category", "miscellaneous", "other"];

  let target = null;
  const possibleToggles = document.querySelectorAll('div[role="combobox"], div[aria-haspopup="listbox"], label, div[role="button"]');
  for (let el of possibleToggles) {
    const aria = (el.getAttribute("aria-label") || "").toLowerCase();
    if (aria.includes(label.toLowerCase())) { target = el; break; }
  }
  if (!target) {
    const spans = document.querySelectorAll("span");
    for (let s of spans) {
      if (s.innerText && s.innerText.trim().toLowerCase() === label.toLowerCase()) {
        target = s.closest('div[role="button"]') || s.closest('div[role="combobox"]') || s.parentElement;
        break;
      }
    }
  }

  // ─── Fill-Missing Guard ─────────────────────────────────────────────────────
  if (fillMissingOnly && target) {
    const currentText = (target.innerText || target.getAttribute("aria-label") || target.textContent || "").trim().toLowerCase();
    const isEmptyOrDefault = emptyPlaceholders.some(p => currentText === p.toLowerCase() || currentText === label.toLowerCase()) ||
      currentText.includes("miscellaneous") ||
      currentText.match(/\bother\b/);

    const isCategory = label.toLowerCase() === "category";

    if (!isEmptyOrDefault && currentText.length > 0 && !isCategory) {
      console.log(`[MARKHOR] SKIPPED (fill-missing=1): "${currentText}" — Dropdown: "${label}"`);
      return true;
    }
  }

  if (target) {
    let currentText = (target.innerText || target.textContent || "").toLowerCase();
    if (target.parentElement) currentText += " " + (target.parentElement.innerText || target.parentElement.textContent || "").toLowerCase();

    if (currentText.includes(value.toLowerCase())) {
      console.log(`[MARKHOR] Dropdown "${label}" already has value "${value}". Skipping.`);
      return true;
    }

    target.scrollIntoView({ block: "center" });
    await sleep(300);
    target.click();
    await sleep(800);
    return await retrySelectOption(value, 0);
  }
  return false;
}

async function retrySelectOption(value, count) {
  if (count > 20) return false;
  const options = document.querySelectorAll("div[role='option'], div[role='menuitem'], span.x193iq5w");
  for (let op of options) {
    const text = op.innerText ? op.innerText.trim().toLowerCase() : "";
    if (text === value.toLowerCase() || (text.includes(value.toLowerCase()) && text.length < value.length + 15)) {
      op.click();
      return true;
    }
  }
  await sleep(200);
  return await retrySelectOption(value, count + 1);
}

/* TAGS */
function fillProductTag(value) {
  if (!value) return;
  let textareas = document.querySelectorAll("textarea");
  let tagField = null;
  for (let ta of textareas) {
    let p = ta.getAttribute("placeholder") || "";
    let a = ta.getAttribute("aria-label") || "";
    if (p.toLowerCase().includes("tag") || a.toLowerCase().includes("tag")) { tagField = ta; break; }
  }
  if (!tagField && textareas.length > 1) tagField = textareas[textareas.length - 1];
  if (tagField) {
    tagField.focus();
    document.execCommand('insertText', false, value);
    setTimeout(() => {
      tagField.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true, code: "Enter", keyCode: 13 }));
    }, 300);
  }
}

/* ─── CONTINUOUS DRAFT SCRAPER (PERSISTENT) ─── */
let allDiscoveredDrafts = new Set();

async function syncDraftsWithStorage() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["discoveredDraftIds", "lastDraftScrapeTime"], (data) => {
      const now = Date.now();
      const lastTime = data.lastDraftScrapeTime || 0;

      // Auto-clear if data is older than 4 hours (stale session)
      if (now - lastTime > 4 * 60 * 60 * 1000) {
        console.log("MARKHOR: Clearing stale draft storage (older than 4 hours).");
        chrome.storage.local.set({ discoveredDraftIds: [], lastDraftScrapeTime: 0 });
        resolve();
        return;
      }

      const storedIds = data.discoveredDraftIds || [];
      storedIds.forEach(id => allDiscoveredDrafts.add(id));
      resolve();
    });
  });
}

async function saveDraftsToStorage() {
  const idsArray = Array.from(allDiscoveredDrafts);
  await chrome.storage.local.set({
    discoveredDraftIds: idsArray,
    lastDraftScrapeTime: Date.now()
  });
}

function startBackgroundScraper() {
  const isSellingPage = window.location.href.includes("/selling") ||
    window.location.href.includes("/marketplace/you") ||
    window.location.href.includes("sk=selling");

  if (!isSellingPage) return;

  console.log("MARKHOR: Background Draft Scraper Active...");

  // Sync initially
  syncDraftsWithStorage().then(() => {
    console.log(`MARKHOR: Loaded ${allDiscoveredDrafts.size} existing drafts from storage.`);
  });

  setInterval(() => {
    const mainArea = document.querySelector('[role="main"]') || document.body;
    const links = mainArea.querySelectorAll('a[href]');

    let foundNew = false;
    links.forEach(a => {
      const href = a.href || "";
      const match = href.match(/listing_id=(\d+)/);
      if (match && match[1] && match[1].length >= 10) {
        if (!allDiscoveredDrafts.has(match[1])) {
          allDiscoveredDrafts.add(match[1]);
          foundNew = true;
        }
      }
    });

    if (foundNew) {
      saveDraftsToStorage();
      console.log(`MARKHOR: Drafts updated. Total: ${allDiscoveredDrafts.size}`);
    }
  }, 2000);
}

function scrapeDraftLinks() {
  console.log("MARKHOR: Performing LIVE draft scrape...");
  const mainArea = document.querySelector('[role="main"]') || document.body;
  const allLinks = mainArea.querySelectorAll('a[href]');
  
  const liveLinksSet = new Set();
  allLinks.forEach(a => {
    const href = a.href || "";
    const match = href.match(/listing_id=(\d+)/);
    if (match && match[1] && match[1].length >= 10) {
      liveLinksSet.add(match[1]);
    }
  });

  const finalLinks = Array.from(liveLinksSet).map(id => {
    return `https://www.facebook.com/marketplace/edit/?listing_id=${id}`;
  });

  console.log("MARKHOR: Found " + finalLinks.length + " LIVE drafts on page.");
  return finalLinks;
}

// Start continuous scraper
startBackgroundScraper();

// Start sequence: IMMEDIATE
autofillData();

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "retryAutofill") {
    isAutofilled = false;
    autofillData();
    sendResponse({ status: "started" });
  } else if (request.action === "RECHECK_FILL") {
    console.log("MARKHOR: Focus detected, re-checking for missing data...");
    autofillData(true); // Fill missing mode
    sendResponse({ status: "rechecking" });
  } else if (request.action === "scrapeDrafts") {
    const links = scrapeDraftLinks();
    sendResponse({ links: links });
  } else if (request.action === "clearScrapedDrafts") {
    allDiscoveredDrafts.clear();
    saveDraftsToStorage();
    sendResponse({ success: true });
  }
  return true;
});

// Added by Claude / Antigravity for opening drafts on Enter key
document.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    // Optional safeguard: ignore if typing in an input field
    const activeTag = document.activeElement ? document.activeElement.tagName : "";
    if (activeTag === "INPUT" || activeTag === "TEXTAREA") return;

    const currentURL = window.location.href;

    if (currentURL.includes("/marketplace/") || currentURL.includes("/selling")) {
      const links = scrapeDraftLinks();

      if (links && links.length > 0) {
        chrome.runtime.sendMessage({ action: "openDraftLinks", links: links });
        console.log(`[MARKHOR Content] Sent ${links.length} draft links to background.`);
      } else {
        console.warn("[MARKHOR Content] No draft links found on this page.");
      }
    }
  }
});

// ─── Message Listener: handles typeLocation and selectLocation ───────────────
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

  if (request.action === "typeLocation") {
    console.log(`[Content] Received typeLocation: "${request.location}"`);
    typeLocationIntoField(request.location).then((success) => {
      sendResponse({ success, location: request.location });
    });
    return true;
  }

  if (request.action === "silentTypeAndSelect") {
    console.log(`[Content] Silent Auto-Start (STABLE): "${request.location}"`);
    typeLocationIntoField(request.location).then(async (typed) => {
      if (typed) {
        await sleep(1200); // Background-safe sleep
        const success = await selectLocationFromDropdown();
        sendResponse({ success });
      } else {
        sendResponse({ success: false });
      }
    });
    return true;
  }

});