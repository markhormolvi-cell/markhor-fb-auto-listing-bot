// MARKHOR - PRO BACKGROUND ENGINE (V5 - STABLE)
const TRACKING_URL = "https://script.google.com/macros/s/AKfycbzCU5ukewBnOgc9gkiv9h-Il38Bgw5QeCE4NrQCb7aQDNJHWQaSRg_dvgYvE6WBFyK-/exec";

// Smart Staggered Tracking for high-scale (150+ profiles)
function scheduleNextTracking() {
  const min = 2 * 60 * 1000; // 2 minutes
  const max = 5 * 60 * 1000; // 5 minutes
  const randomDelay = Math.floor(Math.random() * (max - min + 1)) + min;

  setTimeout(() => {
    runUserTracking().then(scheduleNextTracking);
  }, randomDelay);
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ isBlocked: false, hasSynced: false });
  runUserTracking().then(scheduleNextTracking);
});

// Start initial tracking cycle
scheduleNextTracking();

async function runUserTracking() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["deviceId", "profileId"], async (localData) => {
      let deviceId = localData.deviceId;
      let profileId = localData.profileId;

      if (!deviceId) {
        // Screen is not available in Service Workers, using available properties
        const specs = [
          navigator.platform,
          navigator.language,
          navigator.userAgent.split(') ')[0]
        ].join('|');
        let hash = 0;
        for (let i = 0; i < specs.length; i++) {
          hash = ((hash << 5) - hash) + specs.charCodeAt(i);
          hash |= 0;
        }
        deviceId = "PC-" + Math.abs(hash).toString(16).toUpperCase();
      }

      if (!profileId) {
        profileId = "PROF-" + Math.random().toString(36).substring(2, 8).toUpperCase();
      }

      chrome.storage.local.set({ deviceId, profileId });

      let ip = "Unknown", loc = "Unknown";
      try {
        const res = await fetch("http://ip-api.com/json/");
        const ipData = await res.json();
        if (ipData.status === "success") {
          ip = ipData.query;
          loc = `${ipData.city}, ${ipData.country}`;
        }
      } catch (e) { }

      const payload = {
        action: "track",
        version: "2.0", // Nayi version ki pehchan
        deviceId: deviceId,
        profileId: profileId,
        ip: ip,
        location: loc,
        pcDetails: `${navigator.platform} | Chrome`
      };

      try {
        const response = await fetch(TRACKING_URL, {
          method: "POST",
          headers: { "Content-Type": "text/plain" },
          body: JSON.stringify(payload)
        });
        const result = await response.json();

        chrome.storage.local.set({
          isBlocked: result.isBlocked,
          systemMessage: result.systemMessage,
          broadcast: result.broadcast,
          hasSynced: true
        }, () => {
          if (result.isBlocked) {
            chrome.tabs.query({}, (tabs) => {
              tabs.forEach(tab => {
                chrome.tabs.sendMessage(tab.id, { action: "FORCE_STOP" }).catch(e => { });
              });
            });
          }
          resolve(); // Resolve promise after storage is updated
        });
      } catch (e) {
        resolve(); // Resolve even on error to prevent hanging
      }
    });
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "force_sync") {
    runUserTracking().then(() => sendResponse({ success: true }));
    return true;
  }

  if (msg.action === "smart_open_tabs") {
    handleSmartTabs(msg);
    sendResponse({ success: true });
    return true;
  }

  if (msg.action === "open_drafts") {
    chrome.tabs.query({ url: "*://*.facebook.com/marketplace/*" }, (tabs) => {
      const sellingTab = tabs.find(t => t.url.includes("/selling") || t.url.includes("/marketplace/you"));

      if (!sellingTab) {
        sendResponse({ message: "Please open Facebook Selling/Drafts page first!" });
        return;
      }

      chrome.tabs.sendMessage(sellingTab.id, { action: "scrapeDrafts" }, (response) => {
        if (response && response.links && response.links.length > 0) {
          staggeredDraftOpener(response.links);
          // Clear the list so they don't open again next time
          chrome.tabs.sendMessage(sellingTab.id, { action: "clearScrapedDrafts" }).catch(() => { });
          sendResponse({ message: `Opening ${response.links.length} drafts...` });
        } else {
          sendResponse({ message: "No drafts found. Try scrolling down on the Selling page." });
        }
      });
    });
    return true;
  }

  if (msg.action === "openDraftLinks") {
    if (msg.links && msg.links.length > 0) {
      staggeredDraftOpener(msg.links);
    }
    return true;
  }

  // 🚀 BACKGROUND TIMER SERVICE: Bypasses tab throttling
  if (msg.action === "bgSleep") {
    setTimeout(() => sendResponse({}), msg.ms);
    return true; 
  }
});

async function staggeredDraftOpener(links) {
  for (let i = 0; i < links.length; i++) {
    chrome.tabs.create({ url: links[i], active: false });
    const delay = Math.floor(Math.random() * 1500) + 2000; // 2s - 3.5s delay
    await new Promise(r => setTimeout(r, delay));
  }
}

async function handleSmartTabs(msg) {
  const countA = msg.countA || 0;
  const countB = msg.countB || 0;
  const totalCount = countA + countB;

  chrome.storage.local.get(["smartDayCount"], async (res) => {
    let day = (res.smartDayCount || 0) + 1;
    if (day > 5) day = 1;
    chrome.storage.local.set({ smartDayCount: day });

    const patterns = {
      1: [1000, 1300, 1600, 1200, 1500],
      2: [1200, 1500, 1100, 1700, 1400],
      3: [1500, 1100, 1800, 1300, 1600],
      4: [1300, 1700, 1200, 1900, 1500],
      5: [1800, 1400, 1900, 1200, 1700]
    };

    const currentPattern = patterns[day];

    let tabIds = [];

    // --- ACTIVATION LOOP (Switching every 3 seconds) ---
    const activationLoop = async () => {
      for (let i = 1; i < totalCount; i++) {
        await new Promise(r => setTimeout(r, 3000)); // Wait 3s on current tab

        // Wait until the next tab is actually created if opening is slow
        while (tabIds.length <= i) {
          await new Promise(r => setTimeout(r, 200));
        }

        const safeSwitch = async (tabId, retries = 3) => {
          try {
            console.log(`MARKHOR: Switching to Tab ${i + 1}`);
            await chrome.tabs.update(tabId, { active: true });

            // Trigger Smart Re-check on Focus
            setTimeout(() => {
              chrome.tabs.sendMessage(tabId, { action: "RECHECK_FILL" }).catch(() => { });
            }, 500);

            // Auto-refresh check
            chrome.scripting.executeScript({
              target: { tabId: tabId },
              func: () => {
                const text = document.body.innerText || "";
                const isError = text.includes("Something went wrong") ||
                  text.includes("Reload Page") ||
                  (document.title.includes("Facebook") && text.length < 200);
                if (isError) { location.reload(); }
              }
            }).catch(() => { });

          } catch (e) {
            if (retries > 0) {
              console.warn("MARKHOR: Tab busy, retrying in 500ms...");
              await new Promise(r => setTimeout(r, 500));
              await safeSwitch(tabId, retries - 1);
            }
          }
        };

        await safeSwitch(tabIds[i]);
      }
    };

    // Start activation loop in background
    activationLoop();

    // --- CREATION LOOP (Opening at pattern speed) ---
    for (let i = 0; i < totalCount; i++) {
      const isFirst = (i === 0);

      // Smart Batch Distribution (Based on User Counts)
      let batchFlag = "";
      if (msg.isBatchMode) {
        batchFlag = (i < countA) ? "&batch=A" : "&batch=B";
      }

      const tab = await chrome.tabs.create({
        url: `https://www.facebook.com/marketplace/create/item#idx=${i}${batchFlag}`,
        active: isFirst
      });
      tabIds.push(tab.id);

      if (i < totalCount - 1) {
        const baseDelay = currentPattern[i % currentPattern.length];
        const jitter = Math.floor(Math.random() * 200) - 100;
        const finalDelay = Math.min(2500, Math.max(1000, baseDelay + jitter));

        console.log(`MARKHOR: Next tab opening in ${finalDelay}ms...`);
        await new Promise(r => setTimeout(r, finalDelay));
      }
    }
  });
}
