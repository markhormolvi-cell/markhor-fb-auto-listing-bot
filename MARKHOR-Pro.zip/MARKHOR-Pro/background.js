// MARKHOR - PRO BACKGROUND ENGINE (V5.5 - SMART FINGERPRINT)
const TRACKING_URL = "https://markhor-proxy.vercel.app/api/proxy";
const SECURITY_KEY = "MARKHOR_SECURE_2024";

// --- SMART FINGERPRINT GENERATOR (1 PC = 1 ID across all profiles) ---
async function generateSmartDeviceId() {
  const specs = [
    navigator.platform,
    navigator.language,
    navigator.hardwareConcurrency || "U", // CPU Cores
    (navigator.deviceMemory || "U"),      // RAM (if available)
    Intl.DateTimeFormat().resolvedOptions().timeZone, // Timezone
    // Add more stable specs that don't change per profile
  ].join('|');

  // Simple Hash function
  let hash = 0;
  for (let i = 0; i < specs.length; i++) {
    hash = ((hash << 5) - hash) + specs.charCodeAt(i);
    hash |= 0;
  }
  return "PC-" + Math.abs(hash).toString(16).toUpperCase();
}

function scheduleNextTracking() {
  const min = 2 * 60 * 1000;
  const max = 5 * 60 * 1000;
  const randomDelay = Math.floor(Math.random() * (max - min + 1)) + min;
  setTimeout(() => { runUserTracking().then(scheduleNextTracking); }, randomDelay);
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ isBlocked: false, hasSynced: false });
  runUserTracking().then(scheduleNextTracking);
});

scheduleNextTracking();

async function runUserTracking() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["deviceId", "profileId"], async (localData) => {
      let deviceId = localData.deviceId;
      let profileId = localData.profileId;

      // Use Smart Fingerprint if deviceId is missing
      if (!deviceId) {
        deviceId = await generateSmartDeviceId();
      }

      if (!profileId) {
        profileId = "PROF-" + Math.random().toString(36).substring(2, 8).toUpperCase();
      }

      chrome.storage.local.set({ deviceId, profileId });

      let ip = "Unknown", loc = "Unknown";
      try {
        const res = await fetch("http://ip-api.com/json/");
        const ipData = await res.json();
        if (ipData.status === "success") {
          ip = ipData.query;
          loc = `${ipData.city}, ${ipData.country}`;
        }
      } catch (e) { }

      const payload = {
        action: "track",
        version: "2.0",
        deviceId: deviceId,
        profileId: profileId,
        ip: ip,
        location: loc,
        pcDetails: `${navigator.platform} | ${navigator.hardwareConcurrency} Cores`
      };

      try {
        const response = await fetch(TRACKING_URL, {
          method: "POST",
          headers: { 
            "Content-Type": "application/json",
            "x-markhor-key": SECURITY_KEY
          },
          body: JSON.stringify(payload)
        });
        const result = await response.json();

        chrome.storage.local.set({
          isBlocked: result.isBlocked,
          systemMessage: result.systemMessage,
          broadcast: result.broadcast,
          voiceUrl: result.voiceUrl,
          hasHeardVoice: result.hasHeardVoice,
          hasSynced: true
        }, () => {
          if (result.isBlocked) {
            chrome.tabs.query({}, (tabs) => {
              tabs.forEach(tab => {
                chrome.tabs.sendMessage(tab.id, { action: "FORCE_STOP" }).catch(e => { });
              });
            });
          }
          resolve(); 
        });
      } catch (e) {
        resolve(); 
      }
    });
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "force_sync") {
    runUserTracking().then(() => sendResponse({ success: true }));
    return true;
  }

  if (msg.action === "smart_open_tabs") {
    handleSmartTabs(msg);
    sendResponse({ success: true });
    return true;
  }

  if (msg.action === "open_drafts") {
    chrome.tabs.query({ url: "*://*.facebook.com/marketplace/*" }, (tabs) => {
      const sellingTab = tabs.find(t => t.url.includes("/selling") || t.url.includes("/marketplace/you"));
      if (!sellingTab) {
        sendResponse({ message: "Please open Facebook Selling/Drafts page first!" });
        return;
      }
      chrome.tabs.sendMessage(sellingTab.id, { action: "scrapeDrafts" }, (response) => {
        if (response && response.links && response.links.length > 0) {
          staggeredDraftOpener(response.links);
          chrome.tabs.sendMessage(sellingTab.id, { action: "clearScrapedDrafts" }).catch(() => { });
          sendResponse({ message: `Opening ${response.links.length} drafts...` });
        } else {
          sendResponse({ message: "No drafts found. Try scrolling down on the Selling page." });
        }
      });
    });
    return true;
  }

  if (msg.action === "openDraftLinks") {
    if (msg.links && msg.links.length > 0) {
      staggeredDraftOpener(msg.links);
    }
    return true;
  }

  if (msg.action === "voice_heard") {
    chrome.storage.local.get(["deviceId", "voiceUrl"], async (data) => {
      try {
        await fetch(TRACKING_URL, {
          method: "POST",
          headers: { 
            "Content-Type": "application/json",
            "x-markhor-key": SECURITY_KEY
          },
          body: JSON.stringify({
            action: "voice_heard",
            password: "Markhor/@1AbdullahSattar",
            deviceId: data.deviceId,
            voiceUrl: data.voiceUrl
          })
        });
        chrome.storage.local.set({ hasHeardVoice: true });
        sendResponse({ success: true });
      } catch (e) {
        sendResponse({ success: false });
      }
    });
    return true;
  }

  if (msg.action === "bgSleep") {
    setTimeout(() => sendResponse({}), msg.ms);
    return true; 
  }

  if (msg.action === "start_location_blast") {
    const locations = msg.locations.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    chrome.tabs.query({ url: ["*://*.facebook.com/marketplace/create/item*", "*://*.facebook.com/marketplace/edit/*"]}, (tabs) => {
      if (tabs.length === 0) {
        sendResponse({ message: "No Marketplace 'Create' or 'Edit' tabs found!" });
        return;
      }
      tabs.forEach((tab, index) => {
        const loc = locations[index % locations.length];
        chrome.tabs.sendMessage(tab.id, { action: "silentTypeAndSelect", location: loc }, () => {
          if (chrome.runtime.lastError) { }
        });
      });
      sendResponse({ message: `Blasting ${locations.length} locations across ${tabs.length} tabs...` });
    });
    return true;
  }
});

async function staggeredDraftOpener(links) {
  for (let i = 0; i < links.length; i++) {
    chrome.tabs.create({ url: links[i], active: false });
    const delay = Math.floor(Math.random() * 700) + 800; 
    await new Promise(r => setTimeout(r, delay));
  }
}

async function handleSmartTabs(msg) {
  const countA = msg.countA || 0;
  const countB = msg.countB || 0;
  const totalCount = countA + countB;

  chrome.storage.local.get(["smartDayCount"], async (res) => {
    let day = (res.smartDayCount || 0) + 1;
    if (day > 5) day = 1;
    chrome.storage.local.set({ smartDayCount: day });

    const patterns = {
      1: [1000, 1300, 1600, 1200, 1500],
      2: [1200, 1500, 1100, 1700, 1400],
      3: [1500, 1100, 1800, 1300, 1600],
      4: [1300, 1700, 1200, 1900, 1500],
      5: [1800, 1400, 1900, 1200, 1700]
    };
    const currentPattern = patterns[day];
    let tabIds = [];

    const activationLoop = async () => {
      for (let i = 1; i < totalCount; i++) {
        await new Promise(r => setTimeout(r, 3000));
        while (tabIds.length <= i) {
          await new Promise(r => setTimeout(r, 200));
        }
        const safeSwitch = async (tabId, retries = 3) => {
          try {
            await chrome.tabs.update(tabId, { active: true });
            setTimeout(() => {
              chrome.tabs.sendMessage(tabId, { action: "RECHECK_FILL" }).catch(() => { });
            }, 500);
            chrome.scripting.executeScript({
              target: { tabId: tabId },
              func: () => {
                const text = document.body.innerText || "";
                const isError = text.includes("Something went wrong") || text.includes("Reload Page") || (document.title.includes("Facebook") && text.length < 200);
                if (isError) { location.reload(); }
              }
            }).catch(() => { });
          } catch (e) {
            if (retries > 0) {
              await new Promise(r => setTimeout(r, 500));
              await safeSwitch(tabId, retries - 1);
            }
          }
        };
        await safeSwitch(tabIds[i]);
      }
    };
    // activationLoop(); // DISABLED: Stopping automatic tab switching as per user request.

    for (let i = 0; i < totalCount; i++) {
      const isFirst = (i === 0);
      let batchFlag = msg.isBatchMode ? ((i < countA) ? "&batch=A" : "&batch=B") : "";
      const tab = await chrome.tabs.create({
        url: `https://www.facebook.com/marketplace/create/item#idx=${i}${batchFlag}`,
        active: isFirst
      });
      tabIds.push(tab.id);

      if (i < totalCount - 1) {
        const baseDelay = currentPattern[i % currentPattern.length];
        const jitter = Math.floor(Math.random() * 200) - 100;
        const finalDelay = Math.min(2500, Math.max(1000, baseDelay + jitter));
        await new Promise(r => setTimeout(r, finalDelay));
      }
    }
  });
}
