﻿// STABLE BACKUP - DO NOT MODIFY
document.addEventListener("DOMContentLoaded", () => {
  const mainPanel = document.getElementById("main-panel");
  const blockedPanel = document.getElementById("blocked-panel");
  const verifyingPanel = document.getElementById("verifying-panel");
  const announcementBox = document.getElementById("announcement-box");

  // 1. Initial State Check (Local Sync)
  chrome.storage.local.get(["isBlocked", "systemMessage", "hasSynced", "lastAnnouncement", "lastAnnouncementTime", "broadcast"], (data) => {
    const now = Date.now();
    const lastMsg = data.lastAnnouncement || "";
    const lastTime = data.lastAnnouncementTime || 0;

    // Broadcast / Cooldown Logic
    const isNewMessage = data.broadcast && data.broadcast.trim() !== "" && data.broadcast !== lastMsg;
    const isCooldownActive = (now - lastTime) < (24 * 60 * 60 * 1000);
    const shouldShowAnnouncement = data.broadcast && data.broadcast.trim() !== "" && (isNewMessage || !isCooldownActive);

    if (data.isBlocked) {
      showBlocked(true);
    } else if (shouldShowAnnouncement) {
      showAnnouncement(data.broadcast);
    } else if (data.hasSynced) {
      showMain();
    } else {
      if (verifyingPanel) verifyingPanel.style.display = "flex";
    }

    // 2. Background Sync
    chrome.runtime.sendMessage({ action: "force_sync" }, (response) => {
      chrome.storage.local.get(["isBlocked", "systemMessage", "broadcast"], (newData) => {
        if (newData.isBlocked) {
          showBlocked(true);
        } else {
          const updatedNewMsg = newData.broadcast && newData.broadcast.trim() !== "" && newData.broadcast !== lastMsg;
          const shouldShowUpdated = newData.broadcast && newData.broadcast.trim() !== "" && (updatedNewMsg || !isCooldownActive);

          if (shouldShowUpdated) {
            showAnnouncement(newData.broadcast);
          } else {
            showMain();
          }
        }
      });
    });
  });

  function showBlocked(show) {
    if (show) {
      if (blockedPanel) blockedPanel.style.display = "flex";
      if (mainPanel) mainPanel.style.display = "none";
      if (verifyingPanel) verifyingPanel.style.display = "none";

      // Force fetching Device ID from storage
      chrome.storage.local.get(["deviceId"], (res) => {
        const devIdEl = document.getElementById("blocked-device-id");
        if (devIdEl) {
          devIdEl.textContent = res.deviceId || "ID Loading...";
          devIdEl.style.display = "block"; // Ensure it is visible
        }
      });
    }
  }

  function showAnnouncement(msg) {
    if (!msg || msg.trim() === "") return showMain();
    if (verifyingPanel) verifyingPanel.style.display = "flex";
    if (mainPanel) mainPanel.style.display = "none";

    document.getElementById("sync-loader").style.display = "none";
    document.getElementById("sync-text").style.display = "none";
    if (announcementBox) announcementBox.style.display = "block";

    const msgEl = document.getElementById("popup-system-msg");
    if (msgEl) msgEl.textContent = msg;

    const contBtn = document.getElementById('btn-continue');
    if (contBtn) {
      contBtn.onclick = () => {
        chrome.storage.local.set({
          lastAnnouncement: msg,
          lastAnnouncementTime: Date.now()
        }, () => {
          showMain();
        });
      };
    }
  }

  function showMain() {
    if (verifyingPanel) verifyingPanel.style.display = "none";
    if (blockedPanel) blockedPanel.style.display = "none";
    if (mainPanel) mainPanel.style.display = "block";
    initExtension();
  }

  // --- FULL DATA ENTRY & TOOLS LOGIC ---
  function initExtension() {
    if (window.isMarkhorInitialized) return;
    window.isMarkhorInitialized = true;

    const inputs = ['title', 'price', 'description', 'category', 'condition', 'availability', 'productTag', 'tabs', 'locationsList', 'images'];
    let currentBatch = 'A';

    // --- BATCH MODE LOGIC ---
    const batchToggle = document.getElementById('batchModeToggle');
    const batchTabContainer = document.getElementById('batchTabContainer');
    const batchTabs = document.querySelectorAll('.batch-tab');

    chrome.storage.local.get(['isBatchMode'], (res) => {
      if (res.isBatchMode) {
        batchToggle.checked = true;
        batchTabContainer.classList.add('active');
      }
    });

    batchToggle.onchange = () => {
      const isModeOn = batchToggle.checked;
      chrome.storage.local.set({ isBatchMode: isModeOn });
      batchTabContainer.classList.toggle('active', isModeOn);
      if (!isModeOn) switchBatch('A');
    };

    batchTabs.forEach(tab => {
      tab.onclick = () => {
        batchTabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        switchBatch(tab.dataset.batch);
      };
    });

    function switchBatch(batch) {
      // First, save current batch to memory before switching
      saveCurrentData(() => {
        currentBatch = batch;
        loadBatchData(batch);
      });
    }

    function saveCurrentData(callback) {
      const data = {};
      const suffix = (currentBatch === 'B') ? '_B' : '';
      inputs.forEach(id => {
        if (id === 'images') return;
        const el = document.getElementById(id);
        if (el) data[id + suffix] = el.value;
      });
      chrome.storage.local.set(data, callback);
    }

    function loadBatchData(batch) {
      const suffix = (batch === 'B') ? '_B' : '';
      const batchInputs = inputs.map(id => id + suffix);

      chrome.storage.local.get([...batchInputs, 'images' + suffix], (data) => {
        inputs.forEach(id => {
          const el = document.getElementById(id);
          if (el && id !== 'images') {
            const savedValue = data[id + suffix];
            if (savedValue !== undefined && savedValue !== "") {
              el.value = savedValue;
            } else {
              // If no data, set default for selects or empty for text fields
              if (el.tagName === "SELECT") {
                el.selectedIndex = 0;
              } else {
                el.value = "";
              }
            }
          }
        });
        // Reload images preview for this batch
        renderImagePreviews(data['images' + suffix] || []);
      });
    }

    // Load Initial Data
    loadBatchData('A');

    // Save Data Button
    const saveBtn = document.getElementById('save');
    if (saveBtn) {
      saveBtn.onclick = () => {
        saveCurrentData(() => showCustomModal(`Data Saved for Set ${currentBatch}!`));
      };
    }

    // --- Image Handling ---
    const imageUpload = document.getElementById('images');
    const imagePreview = document.getElementById('imagePreview');
    const imageCountText = document.getElementById('imageCount');

    if (imageUpload) {
      imageUpload.onchange = (e) => {
        const files = Array.from(e.target.files);
        if (files.length === 0) return;

        imageCountText.innerText = "Processing images...";
        const base64Images = [];
        let processed = 0;

        files.forEach(file => {
          const reader = new FileReader();
          reader.onload = (event) => {
            base64Images.push(event.target.result);
            processed++;
            if (processed === files.length) {
              const suffix = (currentBatch === 'B') ? '_B' : '';
              const imgData = {};
              imgData['images' + suffix] = base64Images;
              chrome.storage.local.set(imgData, () => {
                renderImagePreviews(base64Images);
              });
            }
          };
          reader.readAsDataURL(file);
        });
      };
    }

    function renderImagePreviews(imgs) {
      if (!imagePreview) return;

      if (!imgs || imgs.length === 0) {
        imagePreview.innerHTML = "";
        if (imageCountText) imageCountText.innerText = "No images selected";
        return;
      }

      imagePreview.innerHTML = "";
      if (imageCountText) imageCountText.innerText = `${imgs.length} Images Selected`;
      imgs.forEach((src, idx) => {
        const div = document.createElement('div');
        div.className = 'preview-item';
        div.innerHTML = `
          <img src="${src}" />
          <span class="remove-img" data-index="${idx}">&times;</span>
        `;
        imagePreview.appendChild(div);
      });

      // Remove image logic
      document.querySelectorAll('.remove-img').forEach(btn => {
        btn.onclick = (e) => {
          const idx = parseInt(e.target.dataset.index);
          const suffix = (currentBatch === 'B') ? '_B' : '';
          chrome.storage.local.get("images" + suffix, (res) => {
            const key = "images" + suffix;
            const newImgs = res[key].filter((_, i) => i !== idx);
            const update = {};
            update[key] = newImgs;
            chrome.storage.local.set(update, () => {
              renderImagePreviews(newImgs);
            });
          });
        };
      });
    }

    // Load initial image previews (handled by loadBatchData)
    // chrome.storage.local.get("images", (res) => {
    //   if (res.images) renderImagePreviews(res.images);
    // });

    // Open Listings Button (Smart Staggered Opening via Background)
    const openBtn = document.getElementById('open');
    if (openBtn) {
      openBtn.onclick = () => {
        chrome.storage.local.get(['isBatchMode', 'tabs', 'tabs_B'], (res) => {
          const countA = parseInt(res.tabs) || 1;
          const countB = parseInt(res.tabs_B) || 0;

          if (res.isBatchMode) {
            showBatchChoiceModal(countA, countB);
          } else {
            // Normal Single Mode
            chrome.runtime.sendMessage({
              action: "smart_open_tabs",
              countA: countA,
              countB: 0,
              isBatchMode: false
            });
            showCustomModal(`Opening ${countA} tabs...`);
          }
        });
      };
    }

    function showBatchChoiceModal(countA, countB) {
      const modal = document.getElementById('customModal');
      const msg = document.getElementById('modalText');
      const icon = document.querySelector('.modal-icon');
      const okBtn = document.getElementById('modalClose');

      if (!modal || !msg) return;

      if (icon) icon.style.display = 'none';
      if (okBtn) okBtn.style.display = 'none';

      msg.innerHTML = `
        <div style="font-size:16px; font-weight:800; margin-bottom:15px; color:var(--primary);">SELECT BATCH OPTION</div>
        <div style="display:grid; gap:10px;">
          <button id="btnSetA" class="action-btn" style="background:rgba(255,49,49,0.1); border:1px solid var(--primary); padding:10px; border-radius:8px; color:white; font-weight:bold; cursor:pointer;">OPEN SET A ONLY (${countA})</button>
          <button id="btnSetB" class="action-btn" style="background:rgba(255,49,49,0.1); border:1px solid var(--primary); padding:10px; border-radius:8px; color:white; font-weight:bold; cursor:pointer;">OPEN SET B ONLY (${countB})</button>
          <button id="btnBoth" class="action-btn" style="background:var(--primary); border:none; padding:10px; border-radius:8px; color:white; font-weight:bold; cursor:pointer;">RUN DUAL BATCH (${countA + countB})</button>
          <button id="btnCancel" class="action-btn" style="background:#333; border:none; padding:10px; border-radius:8px; color:white; font-weight:bold; cursor:pointer;">CANCEL</button>
        </div>
      `;
      modal.classList.add('active');

      document.getElementById('btnSetA').onclick = () => {
        chrome.runtime.sendMessage({ action: "smart_open_tabs", countA: countA, countB: 0, isBatchMode: true });
        modal.classList.remove('active');
        resetModal();
      };
      document.getElementById('btnSetB').onclick = () => {
        chrome.runtime.sendMessage({ action: "smart_open_tabs", countA: 0, countB: countB, isBatchMode: true });
        modal.classList.remove('active');
        resetModal();
      };
      document.getElementById('btnBoth').onclick = () => {
        chrome.runtime.sendMessage({ action: "smart_open_tabs", countA: countA, countB: countB, isBatchMode: true });
        modal.classList.remove('active');
        resetModal();
      };
      document.getElementById('btnCancel').onclick = () => {
        modal.classList.remove('active');
        resetModal();
      };

      function resetModal() {
        setTimeout(() => {
          if (icon) icon.style.display = 'block';
          if (okBtn) okBtn.style.display = 'block';
          msg.innerHTML = "Action Completed!";
        }, 500);
      }
    }

    // Clear All Button
    const clearBtn = document.getElementById('clear');
    if (clearBtn) {
      clearBtn.onclick = () => {
        if (!confirm("Clear all data?")) return;
        inputs.forEach(id => {
          const el = document.getElementById(id);
          if (el) el.value = "";
        });
        chrome.storage.local.remove(inputs, () => showCustomModal("All Data Cleared!"));
      };
    }

    // Tab Switching
    const tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(btn => {
      btn.onclick = () => {
        tabBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const target = btn.dataset.target;
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        document.getElementById(target).classList.add('active');

        if (target === 'content-actions') {
          updateDraftCount();
        }
      };
    });

    function updateDraftCount() {
      const actionText = document.querySelector('#content-actions div');
      if (!actionText) return;

      chrome.tabs.query({ url: "*://*.facebook.com/marketplace/*" }, (tabs) => {
        const sellingTab = tabs.find(t => t.url.includes("/selling") || t.url.includes("/marketplace/you") || t.url.includes("sk=selling"));
        if (sellingTab) {
          chrome.tabs.sendMessage(sellingTab.id, { action: "scrapeDrafts" }, (res) => {
            if (res && res.links) {
              actionText.innerHTML = `<span style="color:#ff3131; font-weight:800; font-size:16px;">${res.links.length}</span> drafts detected.<br>Click ACTION to open all sequentially.`;
            }
          });
        } else {
          chrome.storage.local.get(["discoveredDraftIds"], (data) => {
            const count = (data.discoveredDraftIds || []).length;
            if (count > 0) {
              actionText.innerHTML = `<span style="color:#ff3131; font-weight:800; font-size:16px;">${count}</span> drafts remembered.<br>Open Selling page or click ACTION.`;
            } else {
              actionText.textContent = "Go to your Facebook drafts page and click the button below to auto-open all drafts.";
            }
          });
        }
      });
    }

    // Draft Opener
    const draftBtn = document.getElementById('triggerOpenDrafts');
    if (draftBtn) {
      draftBtn.onclick = () => {
        chrome.runtime.sendMessage({ action: "open_drafts" }, (res) => {
          if (res) {
            showCustomModal(res.message);
            // Update UI after small delay
            setTimeout(updateDraftCount, 1000);
          }
        });
      };
    }

    const clearDraftsBtn = document.getElementById('clearDrafts');
    if (clearDraftsBtn) {
      clearDraftsBtn.onclick = () => {
        chrome.tabs.query({ url: "*://*.facebook.com/marketplace/*" }, (tabs) => {
          const sellingTab = tabs.find(t => t.url.includes("/selling") || t.url.includes("/marketplace/you") || t.url.includes("sk=selling"));
          if (sellingTab) {
            chrome.tabs.sendMessage(sellingTab.id, { action: "clearScrapedDrafts" }, (res) => {
              showCustomModal("Draft list cleared!");
              updateDraftCount();
            });
          } else {
            // If tab not open, clear storage directly
            chrome.storage.local.set({ discoveredDraftIds: [], lastDraftScrapeTime: 0 }, () => {
              showCustomModal("Stored drafts cleared!");
              updateDraftCount();
            });
          }
        });
      };
    }

    // Auto Blast (Locations)
    const blastBtn = document.getElementById('startAutoBlast');
    if (blastBtn) {
      blastBtn.onclick = () => {
        const list = document.getElementById('locationsList').value;
        chrome.runtime.sendMessage({ action: "start_location_blast", locations: list }, (res) => {
          if (res) alert(res.message);
        });
      };
    }

    // Custom Modal Helpers
    const customModal = document.getElementById('customModal');
    const modalClose = document.getElementById('modalClose');
    const modalText = document.getElementById('modalText');

    function showCustomModal(txt) {
      if (!customModal) return alert(txt);
      modalText.textContent = txt;
      customModal.classList.add('active');
    }

    if (modalClose) {
      modalClose.onclick = () => customModal.classList.remove('active');
    }
  }
});
