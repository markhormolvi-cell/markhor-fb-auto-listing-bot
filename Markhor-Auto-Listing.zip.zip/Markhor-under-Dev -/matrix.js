const canvas = document.getElementById("matrix");
const ctx = canvas.getContext("2d");
const bg = document.querySelector(".bgImage");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const letters = "01ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const fontSize = 12;
const columns = canvas.width / fontSize;

const drops = [];

for(let x=0;x<columns;x++){
drops[x]=1;
}

let matrixActive = false;

/* TOGGLE MATRIX / IMAGE */

setInterval(()=>{

matrixActive = !matrixActive;

if(matrixActive){
bg.style.opacity = "0";   // hide image
}else{
bg.style.opacity = "1";   // show image
}

},10000);


/* MATRIX DRAW */

function draw(){

if(!matrixActive){
ctx.clearRect(0,0,canvas.width,canvas.height);
return;
}

ctx.fillStyle="rgba(0,0,0,0.08)";
ctx.fillRect(0,0,canvas.width,canvas.height);

ctx.fillStyle="#00ff9c";
ctx.font=fontSize+"px monospace";

for(let i=0;i<drops.length;i++){

const text=letters[Math.floor(Math.random()*letters.length)];

ctx.fillText(text,i*fontSize,drops[i]*fontSize);

if(drops[i]*fontSize>canvas.height && Math.random()>0.975){
drops[i]=0;
}

drops[i]++;

}

}

setInterval(draw,35);