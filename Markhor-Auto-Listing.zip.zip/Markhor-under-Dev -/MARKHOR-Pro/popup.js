document.addEventListener("DOMContentLoaded", function(){

chrome.storage.local.get([
"title",
"price",
"description",
"category",
"condition",
"availability"
], function(data){

if(data.title) document.getElementById("title").value=data.title;
if(data.price) document.getElementById("price").value=data.price;
if(data.description) document.getElementById("description").value=data.description;
if(data.category) document.getElementById("category").value=data.category;
if(data.condition) document.getElementById("condition").value=data.condition;
if(data.availability) document.getElementById("availability").value=data.availability;

});

});


document.getElementById("saveData").addEventListener("click", function(){

let title=document.getElementById("title").value.trim();
let price=document.getElementById("price").value.trim();
let description=document.getElementById("description").value.trim();
let category=document.getElementById("category").value;
let condition=document.getElementById("condition").value;
let availability=document.getElementById("availability").value;

let fileInput=document.getElementById("imageInput");

let imageDataList=[];
let processed=0;

if(fileInput.files.length>0){

Array.from(fileInput.files).forEach(file=>{

let reader=new FileReader();

reader.onload=function(event){

imageDataList.push(event.target.result);
processed++;

if(processed===fileInput.files.length){

saveData(title,price,description,category,condition,availability,imageDataList);

}

};

reader.readAsDataURL(file);

});

}else{

saveData(title,price,description,category,condition,availability,imageDataList);

}

});


function saveData(title,price,description,category,condition,availability,imageDataList){

chrome.storage.local.set({

title,
price,
description,
category,
condition,
availability,
imageDataList

},function(){

alert("XCall Market Pro\nData Saved Successfully");

});

}


document.getElementById("openTabs").addEventListener("click", function(){

let tabCount=parseInt(document.getElementById("tabCount").value);

let url="https://www.facebook.com/marketplace/create/item";

if(tabCount>0){

for(let i=0;i<tabCount;i++){

chrome.tabs.create({url:url});

}

}else{

alert("Enter number of tabs");

}

});


document.getElementById("clearData").addEventListener("click", function(){

chrome.storage.local.clear(function(){

alert("All Data Cleared");

});

});