function autofillData(){

chrome.storage.local.get([
"title",
"price",
"description",
"category",
"condition",
"availability",
"imageDataList"
],(data)=>{

setTimeout(()=>{

uploadImage(data.imageDataList);

setTimeout(()=>{ fillTitle(data.title); },2000);

setTimeout(()=>{ fillPrice(data.price); },3500);

setTimeout(()=>{ selectDropdown("Category",data.category); },5000);

setTimeout(()=>{ selectDropdown("Condition",data.condition); },7000);

setTimeout(()=>{ selectDropdown("Availability",data.availability); },9000);

setTimeout(()=>{ fillDescription(data.description); },11000);

},2000);

});

}


function uploadImage(imageDataList){

let uploadInput=document.querySelector("input[type='file']");

if(uploadInput && imageDataList && imageDataList.length>0){

fetch(imageDataList[0])
.then(res=>res.blob())
.then(blob=>{

let file=new File([blob],"image.jpg",{type:"image/jpeg"});

let dt=new DataTransfer();
dt.items.add(file);

uploadInput.files=dt.files;
uploadInput.dispatchEvent(new Event("change",{bubbles:true}));

});

}

}


function fillTitle(value){

let titleField=document.querySelector("input[type='text']");

if(titleField && value){

titleField.value=value;
titleField.dispatchEvent(new Event("input",{bubbles:true}));

}

}


function fillPrice(value){

let priceField=document.querySelectorAll("input[type='text']")[1];

if(priceField && value){

priceField.value=value;
priceField.dispatchEvent(new Event("input",{bubbles:true}));

}

}


function fillDescription(value){

let descriptionField=document.querySelector("textarea");

if(descriptionField && value){

descriptionField.value=value;
descriptionField.dispatchEvent(new Event("input",{bubbles:true}));

}

}


function selectDropdown(label,value){

let spans=document.querySelectorAll("span");

spans.forEach(el=>{

if(el.innerText.trim()===label){

el.click();

setTimeout(()=>{

retrySelect(value,0);

},1200);

}

});

}


function retrySelect(value,count){

if(count>5) return;

let options=document.querySelectorAll("span");

let found=false;

options.forEach(op=>{

if(op.innerText.trim()===value){

op.click();
found=true;

}

});

if(!found){

setTimeout(()=>{

retrySelect(value,count+1);

},800);

}

}


autofillData();