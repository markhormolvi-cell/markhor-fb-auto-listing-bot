chrome.runtime.onInstalled.addListener(() => {
    console.log("AutoFill Image Extension Installed!");
});
