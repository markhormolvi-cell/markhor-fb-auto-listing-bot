let isAutofilled = false;

// ─── Helper: Parse a specific param from window.location.hash ────────────────
function getHashParam(paramName) {
  const hash = window.location.hash.replace("#", "");
  const params = new URLSearchParams(hash);
  return params.get(paramName);
}

// ─── Type Location: Set value instantly in background tab ────────────────────
async function typeLocationIntoField(locationName) {
  console.log(`[typeLocation] Setting location: "${locationName}"`);

  const locationSelectors = [
    'input[aria-label="Location"]',
    'input[aria-label="location"]',
    'input[placeholder="Location"]',
    'input[placeholder="Enter a location"]',
    'input[placeholder="Add a location"]',
    'input[aria-label*="ocation"]',
    'div[aria-label="Location"] input',
  ];

  let locationInput = null;

  for (const selector of locationSelectors) {
    locationInput = document.querySelector(selector);
    if (locationInput) {
      console.log(`[typeLocation] Found input via: "${selector}"`);
      break;
    }
  }

  if (!locationInput) {
    console.warn("[typeLocation] Could not find the location input field.");
    return false;
  }

  // Focus the input
  locationInput.scrollIntoView({ behavior: "instant", block: "center" });
  locationInput.focus();
  locationInput.click();

  // React-safe native setter — set the ENTIRE value at once (works in background tabs)
  const nativeSetter = Object.getOwnPropertyDescriptor(
    window.HTMLInputElement.prototype,
    "value"
  ).set;

  // Clear first
  nativeSetter.call(locationInput, "");
  locationInput.dispatchEvent(new Event("input", { bubbles: true }));

  // Set the full location value at once
  nativeSetter.call(locationInput, locationName);
  locationInput.dispatchEvent(new Event("input", { bubbles: true }));
  locationInput.dispatchEvent(new Event("change", { bubbles: true }));

  console.log(`[typeLocation] ✓ Set location to "${locationName}"`);
  return true;
}

// ─── Helper: get React fiber from a DOM element ───────────────────────────────
function getReactFiber(el) {
  const key = Object.keys(el).find(
    (k) =>
      k.startsWith("__reactFiber") ||
      k.startsWith("__reactInternalInstance") ||
      k.startsWith("__reactFiber$") ||
      k.startsWith("__reactProps")
  );
  return key ? el[key] : null;
}

// ─── Helper: walk fiber tree upward AND downward for any event handler ─────────
function fireReactEventOnFiber(el, eventName = "onClick") {
  const fiber = getReactFiber(el);
  if (!fiber) return false;

  let node = fiber;
  let attempts = 0;
  while (node && attempts < 40) {
    attempts++;
    const props = node.memoizedProps || node.pendingProps || {};
    if (typeof props[eventName] === "function") {
      console.log(`[fireReactEventOnFiber] Found ${eventName} on fiber node (upward walk).`);
      try {
        props[eventName]({
          type: "click", target: el, currentTarget: el, bubbles: true, cancelable: true,
          preventDefault: () => {}, stopPropagation: () => {},
        });
        return true;
      } catch (e) {
        console.warn("[fireReactEventOnFiber] Error calling handler:", e);
      }
    }
    node = node.return;
  }

  function walkDown(fiberNode, depth = 0) {
    if (!fiberNode || depth > 15) return false;
    const props = fiberNode.memoizedProps || fiberNode.pendingProps || {};
    if (typeof props[eventName] === "function") {
      console.log(`[fireReactEventOnFiber] Found ${eventName} on fiber child node.`);
      try {
        props[eventName]({
          type: "click", target: el, currentTarget: el, bubbles: true, cancelable: true,
          preventDefault: () => {}, stopPropagation: () => {},
        });
        return true;
      } catch (e) {}
    }
    return walkDown(fiberNode.child, depth + 1) || walkDown(fiberNode.sibling, depth + 1);
  }

  return walkDown(fiber);
}

// ─── Helper: full realistic mouse event sequence with real coordinates ─────────
async function simulateMouseSequence(el) {
  el.scrollIntoView({ behavior: "instant", block: "center" });
  await new Promise((r) => setTimeout(r, 100));

  const rect = el.getBoundingClientRect();
  if (!rect || rect.width === 0) return;

  const x = rect.left + rect.width / 2;
  const y = rect.top + rect.height / 2;

  const shared = {
    bubbles: true, cancelable: true, view: window,
    clientX: x, clientY: y, screenX: window.screenX + x, screenY: window.screenY + y,
    movementX: 0, movementY: 0, button: 0, buttons: 1,
  };

  const events = [
    new PointerEvent("pointerover",  { ...shared, pointerId: 1, isPrimary: true }),
    new MouseEvent("mouseover",      shared),
    new PointerEvent("pointerenter", { ...shared, pointerId: 1, isPrimary: true }),
    new MouseEvent("mouseenter",     shared),
    new PointerEvent("pointermove",  { ...shared, pointerId: 1, isPrimary: true }),
    new MouseEvent("mousemove",      shared),
    new PointerEvent("pointerdown",  { ...shared, pointerId: 1, isPrimary: true }),
    new MouseEvent("mousedown",      shared),
    new PointerEvent("pointerup",    { ...shared, pointerId: 1, isPrimary: true }),
    new MouseEvent("mouseup",        shared),
    new MouseEvent("click",          shared),
  ];

  for (const event of events) {
    el.dispatchEvent(event);
    await new Promise((r) => setTimeout(r, 20));
  }
}

// ─── Helper: elementFromPoint click ──────────────────────────────────────────
async function clickViaPoint(el) {
  el.scrollIntoView({ behavior: "instant", block: "center" });
  await new Promise((r) => setTimeout(r, 100));

  const rect = el.getBoundingClientRect();
  const x = Math.round(rect.left + rect.width / 2);
  const y = Math.round(rect.top + rect.height / 2);

  const topEl = document.elementFromPoint(x, y);
  if (!topEl) return false;

  console.log(`[clickViaPoint] elementFromPoint hit:`, topEl.tagName, topEl.className?.slice?.(0, 60));
  await simulateMouseSequence(topEl);
  return true;
}

// ─── Helper: fire ALL click methods on an element simultaneously ──────────────
async function bruteForceClick(el) {
  console.log("[bruteForceClick] Firing all click strategies on:", el.tagName, el.innerText?.trim()?.slice(0, 50));

  try { el.click(); } catch (e) {}
  await new Promise((r) => setTimeout(r, 50));

  fireReactEventOnFiber(el, "onClick");
  await new Promise((r) => setTimeout(r, 50));

  fireReactEventOnFiber(el, "onMouseDown");
  fireReactEventOnFiber(el, "onMouseUp");
  await new Promise((r) => setTimeout(r, 50));

  await simulateMouseSequence(el);
  await new Promise((r) => setTimeout(r, 50));

  await clickViaPoint(el);
  await new Promise((r) => setTimeout(r, 50));

  let parent = el.parentElement;
  let levels = 0;
  while (parent && levels < 5) {
    try { fireReactEventOnFiber(parent, "onClick"); } catch (e) {}
    try { parent.click(); } catch (e) {}
    parent = parent.parentElement;
    levels++;
    await new Promise((r) => setTimeout(r, 30));
  }
}

// ─── Helper: check if Facebook accepted the location ─────────────────────────
function isLocationAccepted() {
  const allText = document.body.innerText || "";
  const hasError = allText.toLowerCase().includes("please enter a valid location");
  const locationInput = document.querySelector(
    'input[aria-label="Location"], input[aria-label="location"], input[placeholder="Location"]'
  );
  const inputHasValue = locationInput && locationInput.value?.trim().length > 2;
  return !hasError && inputHasValue;
}

// ─── Helper: find suggestion elements near the location input ─────────────────
function findSuggestionElements(locationInput, typedText) {
  const candidates = [];
  const searchTerms = typedText.toLowerCase().split(/[\s,]+/).filter((w) => w.length > 2);

  let container = locationInput.parentElement;
  for (let i = 0; i < 8; i++) {
    if (!container) break;
    container = container.parentElement;
  }

  if (container) {
    const allEls = container.querySelectorAll(
      "div, li, span, a, [role='option'], [role='listitem'], [role='menuitem'], [tabindex]"
    );
    allEls.forEach((el) => {
      const text = (el.innerText || el.textContent || "").trim().toLowerCase();
      if (text.length < 3 || text.length > 300) return;
      if (el === locationInput) return;
      const matchesSearch = searchTerms.some((term) => text.includes(term));
      if (!matchesSearch) return;
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;
      if (rect.top < 0 || rect.bottom > window.innerHeight) return;
      const inputRect = locationInput.getBoundingClientRect();
      if (rect.top < inputRect.bottom - 10) return;
      candidates.push({ el, rect, text });
    });
  }

  if (candidates.length === 0) {
    const inputRect = locationInput.getBoundingClientRect();
    const allEls = document.querySelectorAll("div, li, span, [role='option'], [role='listitem'], [tabindex]");
    allEls.forEach((el) => {
      const text = (el.innerText || el.textContent || "").trim().toLowerCase();
      if (text.length < 3 || text.length > 300) return;
      if (el === locationInput) return;
      const matchesSearch = searchTerms.some((term) => text.includes(term));
      if (!matchesSearch) return;
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;
      if (rect.top < inputRect.bottom - 10) return;
      candidates.push({ el, rect, text });
    });
  }

  const inputRect = locationInput.getBoundingClientRect();
  candidates.sort((a, b) => Math.abs(a.rect.top - inputRect.bottom) - Math.abs(b.rect.top - inputRect.bottom));

  const deduped = [];
  for (const c of candidates) {
    const isChild = deduped.some((d) => d.el.contains(c.el));
    const isParent = deduped.some((d) => c.el.contains(d.el));
    if (!isChild && !isParent) deduped.push(c);
  }

  console.log(`[findSuggestionElements] Found ${deduped.length} candidate(s):`,
    deduped.slice(0, 3).map((c) => c.text.slice(0, 60)));
  return deduped;
}

// ─── Helper: re-trigger Facebook's autocomplete ───────────────────────────────
async function reTriggerAutocomplete(input) {
  input.focus();
  await new Promise((r) => setTimeout(r, 200));
  const lastChar = (input.value || "").slice(-1) || "a";
  ["keydown", "keypress", "input", "change", "keyup"].forEach((type) => {
    const event = type === "input" || type === "change"
      ? new Event(type, { bubbles: true })
      : new KeyboardEvent(type, { key: lastChar, bubbles: true });
    input.dispatchEvent(event);
  });
  await new Promise((r) => setTimeout(r, 800));
}

// ─── MAIN: selectLocationFromDropdown (LEVEL Extension Mode) ──────────────────
async function selectLocationFromDropdown() {
  console.log("[selectLocationFromDropdown] Running exact LEVEL extension logic...");

  const xpath = "/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[2]/div/div/div[1]/div[1]/div/ul/li[1]/div/div[1]/div/div/div/div/div/div/div/div/div[2]/span";
  
  try {
    const element = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;

    if (element) {
        element.click();
        console.log("✅ Clicked first dropdown option (LEVEL XPath):", element.innerText);
        return true;
    } else {
        console.log("⏳ LEVEL XPath element not found in this tab.");
        return false;
    }
  } catch (e) {
    console.error("XPath Error:", e);
    return false;
  }
}


async function autofillData() {
    if (isAutofilled) return;

    const isFillMissingMode = window.location.hash.includes("fill-missing=1");
    console.log(`[autofillData] Starting — Mode: ${isFillMissingMode ? "Fill Missing Fields Only" : "Full Autofill"}`);

    isAutofilled = true;
    
    // CRITICAL: Wait for Facebook's React UI to load the draft data before we check!
    console.log("MARKHOR: Waiting for page to load existing data...");
    await sleep(isFillMissingMode ? 4000 : 1500);

    chrome.storage.local.get([
        "title", "price", "description", "category", "condition", "availability", "productTag", "images", "locationsList"
    ], async (data) => {
        console.log("MARKHOR: Starting RELIABILITY-FIRST Sequential Autofill...");

        // 1. IMAGE UPLOAD FIRST (PRIORITY)
        if (data.images && data.images.length > 0) {
            // Check if images already exist before uploading
            const existingImages = document.querySelectorAll('div[aria-label*="Remove photo"], div[aria-label*="photo"], img[src*="scontent"]');
            if (isFillMissingMode && existingImages.length > 0) {
                console.log("MARKHOR: Images already exist, skipping upload to prevent duplicates.");
            } else {
            let imgIndex = 0;
            const hash = window.location.hash;
            if (hash && hash.includes("idx=")) imgIndex = parseInt(hash.split("idx=")[1]) || 0;

            // Loop images evenly across tabs
            imgIndex = imgIndex % data.images.length;

            console.log("MARKHOR: Uploading Image index:", imgIndex);
            for (let i=0; i<30; i++) {
                const success = await uploadSingleImage(data.images[imgIndex]);
                if (success) break;
                await sleep(500); // Check every 500ms
            }
            
            // CRITICAL: Wait 7 seconds for image to load before doing anything else
            console.log("MARKHOR: Waiting 7 seconds for image processing...");
            await sleep(7000); 
            } // Closes else block
        } // Closes if (data.images && data.images.length > 0)

        // 2. DATA ENTRY (One by one for maximum stability)
        
        // Title
        console.log("MARKHOR: Filling Title...");
        await retryFill(["Title", "What are you selling?", "Product Title"], data.title, false, 30);
        await sleep(500);

        // Price
        console.log("MARKHOR: Filling Price...");
        await retryFill(["Price", "Price (PKR)", "Amount"], data.price, false, 30);
        await sleep(500);

        // Category
        console.log("MARKHOR: Setting Category...");
        for (let i=0; i<3; i++) {
            if (await selectDropdown("Category", data.category)) break;
            await sleep(800);
        }

        // Condition
        console.log("MARKHOR: Setting Condition...");
        for (let i=0; i<3; i++) {
            if (await selectDropdown("Condition", data.condition)) break;
            await sleep(800);
        }

        // Description
        console.log("MARKHOR: Filling Description...");
        await retryFill(["Description", "Write a description"], data.description, true, 30);
        await sleep(500);

        // Availability
        console.log("MARKHOR: Setting Availability...");
        await selectDropdown("Availability", data.availability || "List as in stock");

        // Tags
        if (data.productTag) {
            console.log("MARKHOR: Filling Tags...");
            await sleep(1000);
            fillProductTag(data.productTag);
        }

        console.log("MARKHOR: Stability Autofill Complete! (100% Success)");
    });
}

async function retryFill(placeholders, value, isTextArea = false, maxRetries = 25) {
    if (!value) return true;
    for (let i=0; i<maxRetries; i++) {
        if (fillFieldByPlaceholder(placeholders, value, isTextArea)) return true;
        await sleep(200); // Optimized for speed: check every 200ms instead of 1000ms
    }
    return false;
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/* DIAGNOSTIC: LOG ALL POTENTIAL FIELDS */
function logAllFields() {
    console.log("MARKHOR DIAGNOSTIC: Scanning all inputs...");
    const inputs = document.querySelectorAll("input, textarea, div[role='textbox']");
    inputs.forEach((el, i) => {
        console.log(`MARKHOR DIALOG [${i}]:`, {
            tag: el.tagName,
            type: el.getAttribute("type"),
            placeholder: el.getAttribute("placeholder"),
            ariaLabel: el.getAttribute("aria-label")
        });
    });
}

/* HELPER: FIND BY PLACEHOLDER OR ARIA-LABEL AND TYPE */
async function fillFieldByPlaceholder(placeholders, value, isTextArea = false) {
  const fillMissingOnly = window.location.hash.includes("fill-missing=1");
  if (!value) return true;
  if (typeof placeholders === "string") placeholders = [placeholders];

  let target = null;

  // Search through all provided placeholder variations
  for (const placeholder of placeholders) {
    // Standard input / textarea
    target =
      document.querySelector(`input[placeholder="${placeholder}"]`) ||
      document.querySelector(`textarea[placeholder="${placeholder}"]`);

    // Contenteditable div with aria-label or placeholder attribute
    if (!target) {
      target =
        document.querySelector(`div[aria-label="${placeholder}"][contenteditable="true"]`) ||
        document.querySelector(`div[data-placeholder="${placeholder}"][contenteditable="true"]`) ||
        document.querySelector(`div[role="textbox"][aria-label="${placeholder}"]`);
    }

    if (target) break;
  }

  // Fallback search logic
  if (!target) {
    const elements = document.querySelectorAll("span, label, div.x1lliihq");
    for (const el of elements) {
      const text = el.innerText ? el.innerText.trim().toLowerCase() : "";
      for (const p of placeholders) {
        if (text === p.toLowerCase()) {
          let container = el.closest('div[role="none"]') || el.parentElement;
          target = container.querySelector("input, textarea, div[role='textbox']");
          if (target) break;
          let next = el.nextElementSibling;
          if (next) target = next.querySelector("input, textarea, div[role='textbox']") || (next.matches("input, textarea, div[role='textbox']") ? next : null);
        }
        if (target) break;
      }
      if (target) break;
    }
  }

  if (!target) {
    return false;
  }

  // ─── Fill-Missing Guard ───────────────────────────────────────────────────
  if (fillMissingOnly) {
    const isContentEditable = target.isContentEditable || target.getAttribute("contenteditable") === "true";
    const existingValue = isContentEditable ? (target.innerText || "").trim() : (target.value || "").trim();

    if (existingValue.length > 0 && existingValue !== "0" && existingValue !== "$0" && existingValue !== "PKR 0" && existingValue !== "0.00") {
      console.log(`[MARKHOR] SKIPPED (fill-missing=1): "${existingValue}" — Field: ${placeholders[0]}`);
      return true; // Skip — field already has data
    }
  }

  // ─── Focus & Insert Value ─────────────────────────────────────────────────
  target.scrollIntoView({ behavior: "smooth", block: "center" });
  await new Promise((r) => setTimeout(r, 100)); // Sleep slightly

  target.focus();
  await new Promise((r) => setTimeout(r, 100));

  const isContentEditable = target.isContentEditable || target.getAttribute("contenteditable") === "true";

  try {
    if (isContentEditable) {
      document.execCommand("selectAll", false, null);
      document.execCommand("insertText", false, value);
    } else {
      document.execCommand("selectAll", false, null);
      document.execCommand("insertText", false, value);
    }

    const events = ["input", "change", "blur", "keyup"];
    events.forEach((eventType) => {
      target.dispatchEvent(new Event(eventType, { bubbles: true }));
    });
    return true;
  } catch (e) {
    return false;
  }
}

/* UPLOAD ONLY ONE IMAGE */
function uploadSingleImage(imageUrl) {
    let uploadInput = document.querySelector("input[type='file']");
    if (uploadInput && imageUrl) {
        fetch(imageUrl).then(res => res.blob()).then(blob => {
            let file = new File([blob], "product_image.jpg", { type: "image/jpeg" });
            let dt = new DataTransfer();
            dt.items.add(file);
            uploadInput.files = dt.files;
            uploadInput.dispatchEvent(new Event("change", { bubbles: true }));
            console.log("MARKHOR: Image uploaded successfully.");
        });
        return true;
    }
    return false;
}

/* DROPDOWN IMPROVED */
async function selectDropdown(label, value) {
  if (!value) return true;
  const fillMissingOnly = window.location.hash.includes("fill-missing=1");
  const emptyPlaceholders = ["", "select", "choose", "none", "please select", "select an option", "pick one", "-", "--", "category", "condition", "select a category", "miscellaneous", "other"];

  let target = null;
  const possibleToggles = document.querySelectorAll('div[role="combobox"], div[aria-haspopup="listbox"], label, div[role="button"]');
  for (let el of possibleToggles) {
      const aria = (el.getAttribute("aria-label") || "").toLowerCase();
      if (aria.includes(label.toLowerCase())) { target = el; break; }
  }
  if (!target) {
      const spans = document.querySelectorAll("span");
      for (let s of spans) {
          if (s.innerText && s.innerText.trim().toLowerCase() === label.toLowerCase()) {
              target = s.closest('div[role="button"]') || s.closest('div[role="combobox"]') || s.parentElement;
              break;
          }
      }
  }

  // ─── Fill-Missing Guard ─────────────────────────────────────────────────────
  if (fillMissingOnly && target) {
      const currentText = (target.innerText || target.getAttribute("aria-label") || target.textContent || "").trim().toLowerCase();
      const isEmptyOrDefault = emptyPlaceholders.some(p => currentText === p.toLowerCase() || currentText === label.toLowerCase()) || 
                               currentText.includes("miscellaneous") || 
                               currentText.match(/\bother\b/);

      // Force overwrite for Category because Facebook's AI aggressively auto-selects wrong categories
      const isCategory = label.toLowerCase() === "category";

      if (!isEmptyOrDefault && currentText.length > 0 && !isCategory) {
        console.log(`[MARKHOR] SKIPPED (fill-missing=1): "${currentText}" — Dropdown: "${label}"`);
        return true; // Skip — dropdown already has a meaningful selection
      }
  }

  if (target) {
      let currentText = (target.innerText || target.textContent || "").toLowerCase();
      if (target.parentElement) currentText += " " + (target.parentElement.innerText || target.parentElement.textContent || "").toLowerCase();
      
      if (currentText.includes(value.toLowerCase())) {
          console.log(`[MARKHOR] Dropdown "${label}" already has value "${value}". Skipping.`);
          return true;
      }
      
      target.scrollIntoView({ block: "center" });
      await sleep(300); // Optimized: less scroll wait
      target.click();
      await sleep(800); // Optimized: less menu wait
      return await retrySelectOption(value, 0);
  }
  return false;
}

async function retrySelectOption(value, count) {
    if (count > 20) return false;
    const options = document.querySelectorAll("div[role='option'], div[role='menuitem'], span.x193iq5w");
    for (let op of options) {
        const text = op.innerText ? op.innerText.trim().toLowerCase() : "";
        if (text === value.toLowerCase() || (text.includes(value.toLowerCase()) && text.length < value.length + 15)) {
            op.click();
            return true;
        }
    }
    await sleep(200);
    return await retrySelectOption(value, count + 1);
}

/* TAGS */
function fillProductTag(value) {
    if (!value) return;
    let textareas = document.querySelectorAll("textarea");
    let tagField = null;
    for(let ta of textareas) {
        let p = ta.getAttribute("placeholder") || "";
        let a = ta.getAttribute("aria-label") || "";
        if (p.toLowerCase().includes("tag") || a.toLowerCase().includes("tag")) { tagField = ta; break; }
    }
    if (!tagField && textareas.length > 1) tagField = textareas[textareas.length - 1];
    if (tagField) {
        tagField.focus();
        document.execCommand('insertText', false, value);
        setTimeout(() => {
            tagField.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true, code: "Enter", keyCode: 13 }));
        }, 300);
    }
}

/* SCRAPE DRAFTS (VISUAL DOM MODE) */
function scrapeDraftLinks() {
    console.log("MARKHOR: Visual DOM Scraper Active...");
    let ids = new Set();

    // Only search within the main content to avoid sidebars/menus
    const mainArea = document.querySelector('[role="main"]') || document.body;
    const links = mainArea.querySelectorAll('a[href]');
    
    links.forEach(a => {
        const href = a.href || "";
        // Match standard Facebook listing URLs
        const match = href.match(/listing_id=(\d+)/) || href.match(/\/marketplace\/item\/(\d+)/) || href.match(/\/commerce\/listing\/(\d+)/);
        
        if (match && match[1]) {
            const id = match[1];
            // Facebook IDs are usually long numbers (10+ digits)
            if (id.length >= 10) {
                // Ensure the link is actually visible on the screen
                const rect = a.getBoundingClientRect();
                if (rect.width > 0 && rect.height > 0) {
                    ids.add(id);
                }
            }
        }
    });

    const finalLinks = Array.from(ids).map(id => {
        return `https://www.facebook.com/marketplace/edit/?listing_id=${id}`;
    });

    console.log("MARKHOR: Scraper found " + finalLinks.length + " Drafts.");
    return finalLinks;
}

// Start sequence: IMMEDIATE
autofillData();

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "retryAutofill") {
        isAutofilled = false;
        autofillData();
        sendResponse({status: "started"});
    } else if (request.action === "scrapeDrafts") {
        const links = scrapeDraftLinks();
        sendResponse({links: links});
    }
    return true;
});

// Added by Claude / Antigravity for opening drafts on Enter key
document.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    // Optional safeguard: ignore if typing in an input field
    const activeTag = document.activeElement ? document.activeElement.tagName : "";
    if (activeTag === "INPUT" || activeTag === "TEXTAREA") return;

    const currentURL = window.location.href;

    if (currentURL.includes("/marketplace/") || currentURL.includes("/selling")) {
      const links = scrapeDraftLinks();

      if (links && links.length > 0) {
        chrome.runtime.sendMessage({ action: "openDraftLinks", links: links });
        console.log(`[MARKHOR Content] Sent ${links.length} draft links to background.`);
      } else {
        console.warn("[MARKHOR Content] No draft links found on this page.");
      }
    }
  }
});

// ─── Message Listener: handles typeLocation and selectLocation ───────────────
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

  if (request.action === "typeLocation") {
    console.log(`[Content] Received typeLocation: "${request.location}"`);
    typeLocationIntoField(request.location).then((success) => {
      sendResponse({ success, location: request.location });
    });
    return true;
  }

  if (request.action === "silentTypeAndSelect") {
    console.log(`[Content] Silent Auto-Start: "${request.location}"`);
    typeLocationIntoField(request.location).then(async (typed) => {
      if (typed) {
        await new Promise(r => setTimeout(r, 1200));
        const success = await selectLocationFromDropdown();
        sendResponse({ success });
      } else {
        sendResponse({ success: false });
      }
    });
    return true;
  }

});