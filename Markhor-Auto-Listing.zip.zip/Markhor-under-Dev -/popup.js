document.addEventListener("DOMContentLoaded", function(){

  /* LOG FUNCTION */
  function log(msg){
    let box=document.getElementById("logBox");
    if(!box) return;
    let line=document.createElement("div");
    let time=new Date().toLocaleTimeString();
    line.textContent="["+time+"] "+msg;
    box.appendChild(line);
    box.scrollTop=box.scrollHeight;
  }

  function initExtension(){
    /* LOAD SAVED DATA */
    chrome.storage.local.get(null,function(data){
      log("Loading saved data");
      if(data.title) document.getElementById("title").value=data.title;
      if(data.price) document.getElementById("price").value=data.price;
      if(data.description) document.getElementById("description").value=data.description;
      if(data.productTag) document.getElementById("productTag").value=data.productTag;
      if(data.tabs) document.getElementById("tabs").value=data.tabs;
      if(data.locationsList) {
        const locArea = document.getElementById("locationsList");
        if(locArea) locArea.value = data.locationsList;
      }
      if(data.images){
        let total=data.images.length;
        document.getElementById("imageCount").textContent = (total === 1) ? "1 image selected" : total + " images selected";
        log("Loaded "+total+" saved images");
      }
    });

    /* IMAGE COUNTER */
    const imgInput=document.getElementById("images");
    const imageCount=document.getElementById("imageCount");
    if(imgInput && imageCount){
      imgInput.addEventListener("change",function(){
        const total=imgInput.files.length;
        imageCount.textContent = (total === 0) ? "No images selected" : (total === 1) ? "1 image selected" : total + " images selected";
        log("Selected "+total+" images");
      });
    }

    /* SAVE DATA */
    const saveBtn = document.getElementById("save");
    if(saveBtn){
      saveBtn.addEventListener("click",function(){
        log("Saving data...");
        const title=document.getElementById("title").value;
        const price=document.getElementById("price").value;
        const description=document.getElementById("description").value;
        const category=document.getElementById("category").value;
        const condition=document.getElementById("condition").value;
        const availability=document.getElementById("availability").value;
        const productTag=document.getElementById("productTag").value;
        const tabs=document.getElementById("tabs").value;
        const files=document.getElementById("images").files;

        let imageArray=[];
        let processed=0;

        if(files.length===0){
          chrome.storage.local.set({title,price,description,category,condition,availability,productTag,tabs},function(){
            log("Data saved (no images)");
            alert("Data Saved");
          });
          return;
        }

        for(let i=0;i<files.length;i++){
          let reader=new FileReader();
          reader.onload=function(e){
            imageArray.push(e.target.result);
            processed++;
            if(processed===files.length){
              chrome.storage.local.set({title,price,description,category,condition,availability,productTag,tabs,images:imageArray},function(){
                log("Data saved with "+imageArray.length+" images");
                alert("Data Saved");
              });
            }
          };
          reader.readAsDataURL(files[i]);
        }
      });
    }

    /* OPEN LISTINGS */
    const openBtn = document.getElementById("open");
    if(openBtn){
      openBtn.addEventListener("click",function(){
        chrome.storage.local.get(["tabs"],function(data){
          let count=parseInt(data.tabs)||1;
          log("Starting background listing for "+count+" tabs...");
          
          // Send message to background script so it can open tabs even if popup closes
          chrome.runtime.sendMessage({
            action: "openListings",
            count: count
          }, function(response) {
            if(chrome.runtime.lastError) {
              log("Error starting background process.");
            } else {
              log("Process started. You can now close this popup!");
            }
          });
        });
      });
    }
 
    /* CLEAR DATA */
    const clearBtn = document.getElementById("clear");
    if(clearBtn){
      clearBtn.addEventListener("click",function(){
        chrome.storage.local.clear(function(){
          document.getElementById("title").value="";
          document.getElementById("price").value="";
          document.getElementById("description").value="";
          document.getElementById("productTag").value="";
          document.getElementById("tabs").value="";
          document.getElementById("imageCount").textContent="No images selected";
          log("All data cleared");
          alert("Data Cleared");
        });
      });
    }

    /* TABS SWITCHING LOGIC */
    const tabBtns = document.querySelectorAll(".tab-btn");
    const tabContents = document.querySelectorAll(".tab-content");
    
    tabBtns.forEach(btn => {
      btn.addEventListener("click", () => {
        tabBtns.forEach(b => b.classList.remove("active"));
        tabContents.forEach(c => c.classList.remove("active"));
        btn.classList.add("active");
        const targetId = btn.getAttribute("data-target");
        if(document.getElementById(targetId)) {
          document.getElementById(targetId).classList.add("active");
        }
      });
    });

    // ─── Shared helper: query and filter Marketplace tabs ────────────────────────
    function getMarketplaceTabs(callback) {
      chrome.tabs.query({ url: "*://*.facebook.com/*" }, (allTabs) => {
        const marketplaceTabs = allTabs.filter((tab) => {
          const url = tab.url || "";
          return (
            url.includes("/marketplace/item") ||
            url.includes("/marketplace/create") ||
            url.includes("/marketplace/edit")
          );
        });
        callback(marketplaceTabs);
      });
    }

    // ─── ONE-CLICK AUTO BLAST — Silent Background Execution ────────────────────
    const autoBlastBtn = document.getElementById("startAutoBlast");
    if(autoBlastBtn) {
      autoBlastBtn.addEventListener("click", () => {
        const statusEl = document.getElementById("distributeStatus");
        const locationText = document.getElementById("locationsList").value;
        const locationsArray = locationText.split("\n").map(l => l.trim()).filter(l => l.length > 0);

        if (locationsArray.length === 0) {
          showStatus(statusEl, "⚠ Please enter at least one location.", "#e07b00");
          return;
        }

        getMarketplaceTabs((marketplaceTabs) => {
          if (marketplaceTabs.length === 0) {
            showStatus(statusEl, "⚠ No Marketplace draft tabs found.", "#e07b00");
            return;
          }

          log(`Starting Silent Blast for ${marketplaceTabs.length} tab(s)...`);
          showStatus(statusEl, `🚀 Auto-Blast Started...`, "#45bd62", 15000);

          chrome.runtime.sendMessage({
            action: "start_silent_blast",
            tabs: marketplaceTabs,
            locations: locationsArray
          });
        });
      });
    }

    // Helper: show a temporary status message
    function showStatus(el, message, color = "#45bd62", duration = 3500) {
      if(!el) return;
      el.textContent = message;
      el.style.color = color;
      el.style.display = "block";
      setTimeout(() => {
        el.style.display = "none";
      }, duration);
    }

    /* AUTO OPEN DRAFTS BUTTON LOGIC */
    const triggerOpenDraftsBtn = document.getElementById("triggerOpenDrafts");
    if(triggerOpenDraftsBtn){
      triggerOpenDraftsBtn.addEventListener("click",function(){
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
          const activeTab = tabs[0];
          if (!activeTab.url.includes("facebook.com/marketplace") && !activeTab.url.includes("facebook.com/selling")) {
            alert("Please open the Facebook Marketplace Selling/Drafts page first.");
            return;
          }
          
          log("Scraping draft links from current page...");
          chrome.tabs.sendMessage(activeTab.id, {action: "scrapeDrafts"}, function(response) {
            if (chrome.runtime.lastError || !response || !response.links || response.links.length === 0) {
              log("Error: Could not find any drafts. Try scrolling down.");
            } else {
              const links = response.links;
              log("Found " + links.length + " drafts. Opening now...");
              chrome.runtime.sendMessage({action: "openDraftLinks", links: links});
            }
          });
        });
      });
    }

    /* AI MESSAGE SYSTEM */
    const msg=document.getElementById("msg");
    const states=[
      {text:"Hello there!"}, {text:"How are you doing today?"}, {text:"I'm your automation assistant"},
      {text:"System running smoothly"}, {text:"Preparing automation tools"}, {text:"Ready to post your listing"},
      {text:"Launching marketplace automation"}, {text:"Scanning listing fields"}, {text:"Optimizing your workflow"},
      {text:"Humans type... AI automates"}, {text:"Facebook UI again? good luck"}, {text:"Automation level: Hacker mode"},
      {text:"I enjoy helping you"}, {text:"Your extension is looking great"}, {text:"You're doing great today"},
      {text:"Let's automate everything"}, {text:"Sometimes Facebook UI makes me sad"}, {text:"I'm not sleeping... just thinking"},
      {text:"Thinking about your request"}, {text:"This extension is becoming powerful"}, {text:"Target locked: Marketplace"},
      {text:"WhatsApp support: +92 3194949103"}, {text:"Ringba dashboard available"}
    ];
    let stateIndex=0; let charIndex=0;
    function typeMessage(){
      let current=states[stateIndex];
      if(!msg) return;
      msg.innerHTML=current.text.substring(0,charIndex);
      charIndex++;
      if(charIndex<=current.text.length){
        setTimeout(typeMessage,80);
      } else {
        setTimeout(()=>{
          stateIndex++; charIndex=0;
          if(stateIndex>=states.length) stateIndex=0;
          typeMessage();
        },2000);
      }
    }
    typeMessage();
    /* AD PROTECTION SYSTEM (Frequency Capping) */
    const AD_COOLDOWN = 6 * 60 * 60 * 1000; // 6 Hours in milliseconds
    const AD_BRIDGE_URL = "https://markhor-fb-auto-listing-bot.vercel.app/ad.html"; // UPDATED!

    function handleAdFrequency() {
      chrome.storage.local.get(["lastAdTime"], (data) => {
        const now = Date.now();
        const lastTime = data.lastAdTime || 0;

        if (now - lastTime > AD_COOLDOWN) {
          log("Ad protection check: Pass. Loading ad...");
          const adContainer = document.getElementById("adContainer");
          if (adContainer && AD_BRIDGE_URL !== "https://your-vercel-link.com") {
            adContainer.style.display = "block";
            adContainer.innerHTML = `<iframe src="${AD_BRIDGE_URL}" style="width:100%; height:120px; border:none; background:transparent;"></iframe>`;
            
            // Save current time
            chrome.storage.local.set({ lastAdTime: now });
          }
        } else {
          log("Ad protection check: Active. Skipping ad to prevent ban.");
        }
      });
    }

    handleAdFrequency();

    /* FORCE UPDATE SYSTEM */
    function checkUpdates() {
      const localVersion = chrome.runtime.getManifest().version;
      const remoteVersionUrl = "https://markhor-fb-auto-listing-bot.vercel.app/version.json";

      fetch(remoteVersionUrl)
        .then(res => res.json())
        .then(data => {
          if (data.version !== localVersion) {
            log(`Version Mismatch: Local ${localVersion} vs Remote ${data.version}`);
            const overlay = document.getElementById("updateOverlay");
            if (overlay) overlay.style.display = "flex";
          } else {
            log("Version Check: Up to date.");
          }
        })
        .catch(err => {
          log("Update check failed (maybe offline?): " + err);
        });
    }

    checkUpdates();
  }

  initExtension();
});