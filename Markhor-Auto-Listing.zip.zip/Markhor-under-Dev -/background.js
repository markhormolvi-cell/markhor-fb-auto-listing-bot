chrome.runtime.onInstalled.addListener(() => {
  console.log("MARKHOR Pro extension installed");
});

// ─── SILENT BACKGROUND BLAST (No Tab Switching) ─────────────────────────────
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "start_silent_blast") {
    const tabs = request.tabs;
    const locations = request.locations;

    tabs.forEach((tab, index) => {
      const location = locations[index] || locations[0];
      // Send message to content script to handle it silently
      chrome.tabs.sendMessage(tab.id, { 
        action: "silentTypeAndSelect", 
        location: location 
      });
    });

    sendResponse({ success: true });
    return true;
  }
});

// ─── LOCATION SELECTION BLAST (Background handles this so popup can close) ──
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "start_level_blast") {
    const tabs = request.tabs;
    let currentIndex = 0;

    function processNext() {
      if (currentIndex >= tabs.length) {
        console.log("🚀 LEVEL Blast Complete.");
        return;
      }

      const tabId = tabs[currentIndex].id;
      
      // 1. Activate tab
      chrome.tabs.update(tabId, { active: true }, () => {
        // 2. Short wait for focus
        setTimeout(() => {
          // 3. Inject LEVEL logic with Scroll
          chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: () => {
              // Scroll to location field first
              const input = document.querySelector('input[aria-label="Location"], input[aria-label="location"], input[placeholder="Location"]');
              if (input) {
                input.scrollIntoView({ behavior: "smooth", block: "center" });
              }

              const xpath = "/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[2]/div/div/div[1]/div[1]/div/ul/li[1]/div/div[1]/div/div/div/div/div/div/div/div/div[2]/span";
              const element = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
              if (element) {
                element.click();
                console.log("✅ LEVEL Click Success");
              }
            }
          }, () => {
            currentIndex++;
            setTimeout(processNext, 400); // Super fast speed (Reduced from 800ms)
          });
        }, 500); // Reduced focus wait from 1000ms to 500ms
      });
    }

    processNext();
    sendResponse({ success: true });
    return true;
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "openListings") {
    let count = parseInt(request.count) || 1;
    console.log("MARKHOR: Starting background tab opening for " + count + " tabs");
    
    (async () => {
      for (let i = 0; i < count; i++) {
        if (i > 0) await new Promise(r => setTimeout(r, 2000));
        
        // Retry logic for "Tabs cannot be edited" error
        let success = false;
        let retries = 0;
        while (!success && retries < 5) {
          try {
            await new Promise((resolve, reject) => {
              chrome.tabs.create({
                url: "https://www.facebook.com/marketplace/create/item#idx=" + i,
                active: false
              }, (tab) => {
                if (chrome.runtime.lastError) {
                  console.warn("MARKHOR: Tab creation failed, retrying...", chrome.runtime.lastError.message);
                  reject(chrome.runtime.lastError);
                } else {
                  success = true;
                  console.log("MARKHOR: Opened background tab " + (i + 1));
                  resolve(tab);
                }
              });
            });
          } catch (e) {
            retries++;
            await new Promise(r => setTimeout(r, 1000)); // Wait 1 second before retry
          }
        }
      }
    })();

    sendResponse({ status: "started" });
  } else if (request.action === "openDraftLinks") {
    const links = request.links;

    if (!links || links.length === 0) {
      console.warn("[MARKHOR Background] Received empty links array.");
      sendResponse({ status: "empty" });
      return true;
    }

    console.log(`[MARKHOR Background] Opening ${links.length} draft tabs...`);

    links.forEach((link, index) => {
      // Strip any existing hash first for a clean base URL
      const baseURL = link.includes("#") ? link.split("#")[0] : link;

      // Append only fill-missing mode
      const url = `${baseURL}#fill-missing=1`;

      setTimeout(() => {
        chrome.tabs.create({ url: url, active: false }, (tab) => {
          console.log(`[MARKHOR Background] Opened tab ${index + 1}/${links.length}: ${url}`);
        });
      }, index * 1000);
    });

    sendResponse({ status: "started" });
  }
  return true;
});