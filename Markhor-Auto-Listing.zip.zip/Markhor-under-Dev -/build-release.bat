@echo off
echo ========================================================
echo Markhor Auto Listing - Encrypted Release Builder
echo ========================================================
echo Creating secure version for your customers...
echo.

if not exist "%APPDATA%\npm" mkdir "%APPDATA%\npm"

set SRC=%~dp0
set DEST=%~dp0..\Markhor-Pro

echo 1. Cleaning up old release folder...
if exist "%DEST%" rmdir /s /q "%DEST%"
mkdir "%DEST%"

echo 2. Copying files (ignoring build script)...
xcopy "%SRC%*" "%DEST%\" /E /I /H /Y

echo 3. Removing builder files from release...
if exist "%DEST%\build-release.bat" del /q "%DEST%\build-release.bat"
if exist "%DEST%\exclude.txt" del /q "%DEST%\exclude.txt"
if exist "%DEST%\XCall-Market-Pro" rmdir /s /q "%DEST%\XCall-Market-Pro"

echo 4. Encrypting (Obfuscating) Source Code...
cd "%DEST%"
call npx -y javascript-obfuscator popup.js --output popup.js --compact true --self-defending true --disable-console-output true --string-array true
call npx -y javascript-obfuscator content.js --output content.js --compact true --self-defending true --disable-console-output true --string-array true
call npx -y javascript-obfuscator matrix.js --output matrix.js --compact true --self-defending true --disable-console-output true --string-array true
:: Skipping background.js obfuscation as javascript-obfuscator injects 'window' references which break Manifest V3 Service Workers

echo ========================================================
echo DONE! Check your Desktop for "XCall-Market-Pro-Release"
echo This is the folder you should zip and sell to customers!
echo ========================================================
pause
